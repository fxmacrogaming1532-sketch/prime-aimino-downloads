"""Versão do cliente local distribuído pelo PRIME AIMINO."""

AGENT_VERSION = "1.1.16"


def version_tuple(value: str) -> tuple[int, ...]:
    """Converte versões semânticas simples em uma tupla comparável."""
    numbers = []
    for part in str(value).strip().lstrip("vV").split("."):
        digits = "".join(character for character in part if character.isdigit())
        numbers.append(int(digits or 0))
    return tuple((numbers + [0, 0, 0])[:3])
