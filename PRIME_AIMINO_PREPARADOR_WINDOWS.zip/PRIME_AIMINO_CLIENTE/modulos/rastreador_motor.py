"""Laço de execução e comunicação serial do rastreador."""

from .rastreador import *  # Reúne captura, detecção e configuração compartilhadas.


def parar_movimento_placa(placa, movimento_na_placa):
    """Cancela a trajetória pendente na placa antes de limpar o estado local."""
    if movimento_na_placa:
        enviar_serial(placa, "MOVE 0 0\n")
    return False


def _tracker_main():
    config = carregar_configuracao()
    print(f"Abrindo {config['porta']} a {config['baudrate']} baud...", flush=True)
    print("Botoes: direito=mirar, esquerdo=atirar", flush=True)
    print("O modo de ativacao vem do painel.", flush=True)
    print("Solte os botoes conforme o modo para parar. Ctrl+C encerra.", flush=True)

    try:
        placa_serial = serial.Serial(
            config["porta"],
            config["baudrate"],
            timeout=0,
            write_timeout=0.02,
        )
    except serial.SerialException as erro:
        print(
            f"Não foi possível abrir {config['porta']}: {erro}",
            flush=True,
        )
        return

    with placa_serial as placa:
        time.sleep(2)
        placa.reset_input_buffer()
        configurar_humanizacao_placa(placa, config)

        with mss.MSS() as captura:
            janela_ativa = monitor_selecionado(captura, config)
            if janela_ativa is None:
                monitor = captura.monitors[1]
                janela_ativa = {
                    "hwnd": None,
                    "left": int(monitor["left"]),
                    "top": int(monitor["top"]),
                    "width": int(monitor["width"]),
                    "height": int(monitor["height"]),
                    "monitor_left": int(monitor["left"]),
                    "monitor_top": int(monitor["top"]),
                    "monitor_width": int(monitor["width"]),
                    "monitor_height": int(monitor["height"]),
                    "mss_index": 1,
                    "dxgi_output_idx": 0,
                    "monitor_selecao": "principal",
                }
            diametro, left, top, regiao_fov = calcular_fov_janela(
                janela_ativa, config["fov_diametro"]
            )

            camera_dxgi = iniciar_camera_dxgi(janela_ativa, regiao_fov)
            if camera_dxgi is not None:
                atexit.register(camera_dxgi.stop)

            print(
                f"FOV na janela ativa: centro=({left + diametro // 2}, "
                f"{top + diametro // 2}), diametro={diametro}",
                flush=True,
            )
            print(f"Loop alvo: {config['taxa_alvo_hz']:.0f} Hz", flush=True)
            print(f"Cor: {config['cor_hex']}", flush=True)
            print(f"Modo de ativacao: {config['modo_ativacao']}", flush=True)
            print("Pronto. Use os botoes conforme o modo selecionado para rastrear.\n", flush=True)

            alvo_filtrado_x = None
            alvo_filtrado_y = None
            alvo_associado_x = None
            alvo_associado_y = None
            centro_travado = False
            ultimo_erro_x = None
            ultimo_erro_y = None
            resto_x = 0.0
            resto_y = 0.0
            ultimo_tempo_movimento = time.perf_counter()
            ultimo_estado = None
            candidato_pendente = None
            confirmacoes_candidato = 0
            inicio_aquisicao_alvo = None
            movimento_na_placa = False
            ultimo_teste_tracado_id = config["teste_tracado_id"]
            quadros_nulos_dxgi = 0
            proxima_tentativa_dxgi = time.perf_counter() + 1.0
            intervalo = 1.0 / config["taxa_alvo_hz"]
            proximo_ciclo = time.perf_counter()
            proxima_leitura_config = time.perf_counter()
            proxima_leitura_janela = time.perf_counter()
            try:
                ultimo_mtime_config = CONFIG_PATH.stat().st_mtime_ns
            except OSError:
                ultimo_mtime_config = None
            try:
                ultimo_mtime_pausa = PAUSA_PATH.stat().st_mtime_ns
            except OSError:
                ultimo_mtime_pausa = None
            pausado = ler_estado_pausa()
            hotkey_nome_anterior = config.get("hotkey_pausa", "f8")
            hotkey_anterior = hotkey_esta_pressionada(hotkey_nome_anterior)
            ultima_alternancia_hotkey = 0.0
            proxima_leitura_pausa = time.perf_counter()

            while True:
                inicio = time.perf_counter()
                agora = inicio

                if agora >= proxima_leitura_pausa:
                    try:
                        mtime_pausa = PAUSA_PATH.stat().st_mtime_ns
                    except OSError:
                        mtime_pausa = None
                    if mtime_pausa != ultimo_mtime_pausa:
                        estado_anterior = pausado
                        pausado = ler_estado_pausa()
                        ultimo_mtime_pausa = mtime_pausa
                        if pausado != estado_anterior:
                            emitir_som_estado(pausado, perfil_som_mais_recente(config))
                        # Não reinicializar a borda da hotkey aqui. O arquivo de
                        # pausa também é escrito pela própria hotkey; resetar
                        # o estado nesse ponto fazia a segunda pressão ser
                        # perdida em algumas cadências do loop.
                    proxima_leitura_pausa = agora + 0.10

                hotkey_atual = config.get("hotkey_pausa", "f8")
                if hotkey_atual != "none":
                    hotkey_pressionada = hotkey_esta_pressionada(hotkey_atual)
                    # Alternância por borda (pressiona/solta), com debounce
                    # curto para evitar repetição causada pelo polling.
                    if (
                        hotkey_pressionada
                        and not hotkey_anterior
                        and agora - ultima_alternancia_hotkey >= 0.15
                    ):
                        pausado = not pausado
                        ultima_alternancia_hotkey = agora
                        emitir_som_estado(pausado, perfil_som_mais_recente(config))
                        try:
                            gravar_estado_pausa(pausado)
                            ultimo_mtime_pausa = PAUSA_PATH.stat().st_mtime_ns
                        except OSError as erro:
                            print(f"Falha ao salvar estado de pausa: {erro}", flush=True)
                        print(
                            "Rastreador pausado pela hotkey."
                            if pausado
                            else "Rastreador ativado pela hotkey.",
                            flush=True,
                        )
                    hotkey_anterior = hotkey_pressionada
                else:
                    hotkey_anterior = False

                if agora >= proxima_leitura_janela:
                    nova_janela = monitor_selecionado(captura, config)
                    if nova_janela is not None:
                        chaves_geometria = (
                            "hwnd",
                            "left",
                            "top",
                            "width",
                            "height",
                            "monitor_left",
                            "monitor_top",
                            "monitor_width",
                            "monitor_height",
                            "mss_index",
                            "dxgi_output_idx",
                            "monitor_selecao",
                        )
                        geometria_mudou = any(
                            nova_janela.get(chave) != janela_ativa.get(chave)
                            for chave in chaves_geometria
                        )
                        if geometria_mudou:
                            janela_ativa = nova_janela
                            diametro, left, top, regiao_fov = calcular_fov_janela(
                                janela_ativa, config["fov_diametro"]
                            )
                            camera_dxgi = reiniciar_camera_dxgi(
                                camera_dxgi, janela_ativa, regiao_fov
                            )
                            alvo_filtrado_x = None
                            alvo_filtrado_y = None
                            alvo_associado_x = None
                            alvo_associado_y = None
                            centro_travado = False
                            ultimo_erro_x = None
                            ultimo_erro_y = None
                            resto_x = 0.0
                            resto_y = 0.0
                            candidato_pendente = None
                            confirmacoes_candidato = 0
                            print(
                                "Janela ativa/FOV atualizados; alvo reiniciado.",
                                flush=True,
                            )
                    proxima_leitura_janela = agora + JANELA_ATUALIZACAO_SEGUNDOS

                if agora >= proxima_leitura_config:
                    try:
                        mtime_config = CONFIG_PATH.stat().st_mtime_ns
                    except OSError:
                        mtime_config = None

                    # Só decodifica o JSON quando o painel realmente o alterou.
                    if mtime_config != ultimo_mtime_config:
                        nova_config = carregar_configuracao()
                        ultimo_mtime_config = mtime_config
                        if nova_config != config:
                            teste_solicitado = (
                                nova_config["teste_tracado_id"]
                                != ultimo_teste_tracado_id
                            )
                            fov_mudou = nova_config["fov_diametro"] != config["fov_diametro"]
                            monitor_mudou = (
                                nova_config.get("monitor_selecionado", "principal")
                                != config.get("monitor_selecionado", "principal")
                            )
                            resetar_alvo = configuracao_mudou_alvo(config, nova_config)
                            config = nova_config
                            configurar_humanizacao_placa(placa, config)
                            if teste_solicitado:
                                ultimo_teste_tracado_id = config["teste_tracado_id"]
                                executar_teste_tracado(placa)
                            hotkey_nome_anterior = config.get("hotkey_pausa", "f8")
                            hotkey_anterior = hotkey_esta_pressionada(hotkey_nome_anterior)
                            intervalo = 1.0 / config["taxa_alvo_hz"]
                            proximo_ciclo = agora
                            if fov_mudou or monitor_mudou:
                                nova_area = monitor_selecionado(captura, config)
                                if nova_area is not None:
                                    janela_ativa = nova_area
                                    diametro, left, top, regiao_fov = calcular_fov_janela(
                                        janela_ativa, config["fov_diametro"]
                                    )
                                    camera_dxgi = reiniciar_camera_dxgi(
                                        camera_dxgi, janela_ativa, regiao_fov
                                    )
                            if resetar_alvo:
                                alvo_filtrado_x = None
                                alvo_filtrado_y = None
                                alvo_associado_x = None
                                alvo_associado_y = None
                                centro_travado = False
                                ultimo_erro_x = None
                                ultimo_erro_y = None
                                resto_x = 0.0
                                resto_y = 0.0
                                candidato_pendente = None
                                confirmacoes_candidato = 0
                            print(
                                f"Configuracao atualizada: cor={config['cor_hex']}, "
                                f"tolerancia={config['tolerancia_rgb']}, "
                                f"ganho={config['ganho']}, "
                                f"modo={config['modo_ativacao']}, "
                                f"deteccao={config['modo_deteccao']}",
                                flush=True,
                            )
                    proxima_leitura_config = agora + CONFIG_ATUALIZACAO_SEGUNDOS

                # Valores seguros por ciclo: durante aquisição, atraso ou perda
                # de alvo, nenhum deslocamento antigo pode ser reutilizado.
                desejado_x = 0.0
                desejado_y = 0.0
                mirando, atirando = botoes_esta_pressionados()
                ativado_botoes = modo_ativacao_esta_ativo(
                    config["modo_ativacao"], mirando, atirando
                )
                ativado = (not pausado) and ativado_botoes
                if ativado:
                    if camera_dxgi is not None:
                        try:
                            quadro = camera_dxgi.get_latest_frame()
                        except Exception as erro_captura:
                            quadro = None
                            print(
                                f"Falha temporária no DXGI: {erro_captura}",
                                flush=True,
                            )
                        if quadro is None:
                            quadros_nulos_dxgi += 1
                            if quadros_nulos_dxgi >= 8:
                                camera_dxgi = reiniciar_camera_dxgi(
                                    camera_dxgi, janela_ativa, regiao_fov
                                )
                                quadros_nulos_dxgi = 0
                                proxima_tentativa_dxgi = agora + 1.0
                        else:
                            quadros_nulos_dxgi = 0
                    else:
                        try:
                            quadro = np.asarray(captura.grab(regiao_fov))
                        except Exception as erro_captura:
                            quadro = None
                            print(
                                f"Falha temporária no MSS: {erro_captura}",
                                flush=True,
                            )
                        if agora >= proxima_tentativa_dxgi:
                            camera_dxgi = iniciar_camera_dxgi(
                                janela_ativa, regiao_fov
                            )
                            proxima_tentativa_dxgi = agora + 1.0

                    referencia_alvo = (
                        None
                        if alvo_associado_x is None
                        else (alvo_associado_x, alvo_associado_y)
                    )
                    if quadro is None:
                        alvo_local = None
                    else:
                        alvo_local = detectar_alvo_fov_circular(
                            quadro, config, referencia_alvo
                        )
                else:
                    # Enquanto o botão está solto, não há motivo para capturar
                    # ou processar a tela; isso reduz o custo e a latência na
                    # transição para o próximo acionamento.
                    referencia_alvo = None
                    alvo_local = None

                if not ativado:
                    estado_parado = "pausado" if pausado else "solto"
                    movimento_na_placa = parar_movimento_placa(
                        placa, movimento_na_placa
                    )
                    if ultimo_estado != estado_parado:
                        print(
                            "Rastreador pausado: movimento parado."
                            if pausado
                            else "Botao solto: movimento parado.",
                            flush=True,
                        )
                        ultimo_estado = estado_parado
                    alvo_filtrado_x = None
                    alvo_filtrado_y = None
                    alvo_associado_x = None
                    alvo_associado_y = None
                    centro_travado = False
                    ultimo_erro_x = None
                    ultimo_erro_y = None
                    candidato_pendente = None
                    confirmacoes_candidato = 0
                    inicio_aquisicao_alvo = None
                    resto_x = 0.0
                    resto_y = 0.0
                    if movimento_na_placa:
                        enviar_serial(placa, "MOVE 0 0\n")
                        movimento_na_placa = False
                    ultimo_tempo_movimento = inicio
                elif alvo_local is None:
                    # Estado seguro: sem alvo confirmado, não há movimento.
                    movimento_na_placa = parar_movimento_placa(
                        placa, movimento_na_placa
                    )
                    alvo_filtrado_x = None
                    alvo_filtrado_y = None
                    alvo_associado_x = None
                    alvo_associado_y = None
                    centro_travado = False
                    ultimo_erro_x = None
                    ultimo_erro_y = None
                    candidato_pendente = None
                    confirmacoes_candidato = 0
                    inicio_aquisicao_alvo = None
                    resto_x = 0.0
                    resto_y = 0.0
                    if movimento_na_placa:
                        enviar_serial(placa, "MOVE 0 0\n")
                        movimento_na_placa = False
                    ultimo_tempo_movimento = inicio
                    if ultimo_estado != "sem_alvo":
                        if referencia_alvo is None:
                            print(
                                "Ativacao selecionada, mas sem alvo no FOV.",
                                flush=True,
                            )
                        else:
                            print(
                                "Alvo perdido; movimento zerado e aguardando candidato proximo.",
                                flush=True,
                            )
                        ultimo_estado = "sem_alvo"
                else:
                    ponto_candidato = (float(alvo_local[0]), float(alvo_local[1]))
                    alvo_ja_confirmado = alvo_associado_x is not None
                    confirmacoes_necessarias = (
                        1 if config.get("modo_adaptativo", False)
                        else config["confirmacoes_alvo"]
                    )

                    if not alvo_ja_confirmado:
                        if candidato_pendente is None:
                            candidato_pendente = ponto_candidato
                            confirmacoes_candidato = 1
                        else:
                            delta_x = ponto_candidato[0] - candidato_pendente[0]
                            delta_y = ponto_candidato[1] - candidato_pendente[1]
                            if delta_x * delta_x + delta_y * delta_y <= DISTANCIA_CONFIRMACAO**2:
                                candidato_pendente = (
                                    (candidato_pendente[0] + ponto_candidato[0]) / 2.0,
                                    (candidato_pendente[1] + ponto_candidato[1]) / 2.0,
                                )
                                confirmacoes_candidato += 1
                            else:
                                candidato_pendente = ponto_candidato
                                confirmacoes_candidato = 1

                        if confirmacoes_candidato < confirmacoes_necessarias:
                            # Confirmação somente na aquisição/reaquisição. Durante
                            # esta janela nenhum movimento antigo pode continuar.
                            movimento_na_placa = parar_movimento_placa(
                                placa, movimento_na_placa
                            )
                            alvo_filtrado_x = None
                            alvo_filtrado_y = None
                            inicio_aquisicao_alvo = None
                            resto_x = 0.0
                            resto_y = 0.0
                            if movimento_na_placa:
                                enviar_serial(placa, "MOVE 0 0\n")
                                movimento_na_placa = False
                            ultimo_estado = "confirmando"
                            alvo_local = None
                        else:
                            alvo_associado_x = candidato_pendente[0]
                            alvo_associado_y = candidato_pendente[1]
                            inicio_aquisicao_alvo = inicio
                    
                    if alvo_local is not None and (alvo_ja_confirmado or confirmacoes_candidato >= confirmacoes_necessarias):
                        # O alvo e o centro do FOV estão no mesmo sistema
                        # local. Não usamos GetCursorPos aqui: o HID do Pro
                        # Micro pode ainda estar a caminho quando o próximo
                        # frame é processado, o que cria erro e desvio lateral.
                        alvo_x = float(alvo_local[0])
                        alvo_y = float(alvo_local[1])
                        alvo_associado_x = alvo_x
                        alvo_associado_y = alvo_y
                        centro_fov = diametro * 0.5
                        # Igual ao Pull Height do Prime Aim: desloca o ponto Y
                        # de aterrissagem; não multiplica a força vertical.
                        centro_alvo_y = (
                            centro_fov
                            + float(config["altura_puxada"])
                            + float(config.get("offset_vertical_px", 0))
                        )
                        erro_bruto_x = alvo_x - centro_fov
                        erro_bruto_y = alvo_y - centro_alvo_y

                        parametros = parametros_adaptativos(
                            config, alvo_local, erro_bruto_x, erro_bruto_y
                        )
                        if alvo_filtrado_x is None:
                            alvo_filtrado_x = alvo_x
                            alvo_filtrado_y = alvo_y
                        else:
                            alpha = parametros["filtro"]
                            alvo_filtrado_x += alpha * (alvo_x - alvo_filtrado_x)
                            alvo_filtrado_y += alpha * (alvo_y - alvo_filtrado_y)

                        erro_x = alvo_filtrado_x - centro_fov
                        erro_y = alvo_filtrado_y - centro_alvo_y
                        distancia_erro = math.hypot(erro_x, erro_y)
                        raio_entrada = max(2.0, float(config["zona_morta"]))
                        raio_saida = raio_entrada + max(2.5, raio_entrada * 0.75)
                        if centro_travado:
                            if distancia_erro <= raio_saida:
                                erro_x = 0.0
                                erro_y = 0.0
                            else:
                                centro_travado = False
                        elif distancia_erro <= raio_entrada:
                            centro_travado = True
                            erro_x = 0.0
                            erro_y = 0.0
                        if inicio_aquisicao_alvo is None:
                            inicio_aquisicao_alvo = inicio
                        tempo_aquisicao_ms = (inicio - inicio_aquisicao_alvo) * 1000.0
                        atraso_ms = parametros["atraso_ms"]
                        if tempo_aquisicao_ms < atraso_ms:
                            movimento_na_placa = parar_movimento_placa(
                                placa, movimento_na_placa
                            )
                            resto_x = 0.0
                            resto_y = 0.0
                            if movimento_na_placa:
                                enviar_serial(placa, "MOVE 0 0\n")
                                movimento_na_placa = False
                            ultimo_estado = "aguardando_aquisicao"
                            alvo_local = None

                        if alvo_local is not None:
                            agora_movimento = inicio
                            fator_tempo = limitar(
                                (agora_movimento - ultimo_tempo_movimento) / intervalo,
                                0.75,
                                1.25,
                            )
                            ultimo_tempo_movimento = agora_movimento
                            rampa_ms = parametros["rampa_ms"]
                            if rampa_ms <= 0:
                                fator_rampa = 1.0
                            else:
                                progresso = limitar(
                                    (tempo_aquisicao_ms - atraso_ms) / rampa_ms,
                                    0.0,
                                    1.0,
                                )
                                fator_rampa = progresso * progresso * (3.0 - 2.0 * progresso)
                            erro_movimento_y = erro_y
                            distancia_erro = math.hypot(erro_x, erro_y)
                            distancia_movimento = math.hypot(
                                erro_x, erro_movimento_y
                            )
                            curva_ganho = curva_ganho_prime(distancia_erro, diametro)
                            ganho_aterrissagem = ganho_aterrissagem_prime(
                                distancia_erro, config["filtro_alvo"] * 10.0
                            )
                            ganho_efetivo = limitar(
                                parametros["ganho"]
                                * curva_ganho
                                * ganho_aterrissagem,
                                0.005,
                                2.0,
                            )
                            if sinal_mudou(erro_x, ultimo_erro_x):
                                resto_x = 0.0
                            if sinal_mudou(erro_y, ultimo_erro_y):
                                resto_y = 0.0
                            ultimo_erro_x = erro_x
                            ultimo_erro_y = erro_y

                            tremor_x, tremor_y = microvariacao_suave(
                                inicio, parametros["microtremor_px"]
                            )
                            erro_ativo = distancia_erro > float(config["zona_morta"])
                            if not erro_ativo:
                                tremor_x = 0.0
                                tremor_y = 0.0
                            desejado_x = (
                                erro_x * ganho_efetivo * fator_tempo * fator_rampa
                                if erro_ativo
                                else 0.0
                            ) + tremor_x * fator_rampa
                            desejado_y = (
                                erro_movimento_y
                                * ganho_efetivo
                                * fator_tempo
                                * fator_rampa
                                if erro_ativo
                                else 0.0
                            ) + tremor_y * fator_rampa

                            plano_x = resto_x + desejado_x
                            plano_y = resto_y + desejado_y
                            if erro_ativo:
                                estabilidade = limitar(
                                    float(config["filtro_alvo"]), 0.0, 1.0
                                )
                                proporcao_aterrissagem = limitar(
                                    0.70 - estabilidade * 0.09, 0.58, 0.70
                                )
                                limite_aterrissagem = max(
                                    1.0, distancia_movimento * proporcao_aterrissagem
                                )
                                modulo_plano = math.hypot(plano_x, plano_y)
                                if modulo_plano > limite_aterrissagem:
                                    escala = limite_aterrissagem / modulo_plano
                                    plano_x *= escala
                                    plano_y *= escala

                            # Altura define somente a referência Y; os dois eixos
                            # usam o mesmo limite de velocidade.
                            limite_x = float(parametros["passo_maximo"])
                            limite_y = limite_x
                            plano_x = limitar(plano_x, -limite_x, limite_x)
                            plano_y = limitar(plano_y, -limite_y, limite_y)

                            movimento_x = int(round(plano_x))
                            movimento_y = int(round(plano_y))
                            # O resíduo representa o plano já limitado, como no
                            # Prime Aim, evitando bursts quando o teto é atingido.
                            resto_x = limitar(plano_x - movimento_x, -0.95, 0.95)
                            resto_y = limitar(plano_y - movimento_y, -0.95, 0.95)
                            if movimento_x != 0 or movimento_y != 0:
                                enviar_serial(
                                    placa,
                                    f"MOVE {movimento_x} {movimento_y}\n",
                                )
                                movimento_na_placa = True
                            ultimo_estado = "ativado"

                proximo_ciclo += intervalo
                espera = proximo_ciclo - time.perf_counter()
                if espera > 0:
                    if espera > MARGEM_ESPERA_PRECISA:
                        time.sleep(espera - MARGEM_ESPERA_PRECISA)
                    while time.perf_counter() < proximo_ciclo:
                        pass
                elif time.perf_counter() - inicio > intervalo * 3:
                    proximo_ciclo = time.perf_counter()


def tracker_main():
    """Executa o motor e encerra de forma controlada quando a serial cai."""
    try:
        _tracker_main()
    except FalhaComunicacaoSerial as erro:
        # O processo termina sem traceback; o painel pode registrar a queda e
        # tentar reconectar, enquanto o firmware aplica a liberação de segurança.
        print(f"Falha de comunicação com o Pro Micro: {erro}", flush=True)



