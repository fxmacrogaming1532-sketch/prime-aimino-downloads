"""Opções, perfis, valores padrão e textos de ajuda do painel."""

MODOS_ATIVACAO = {
    "mirando": "Mirando (botão direito)",
    "atirando": "Atirando (botão esquerdo)",
    "ambos": "Ambos — qualquer um dos dois",
    "mirando_atirando": "Mirando + atirando — os dois juntos",
}

MODOS_DETECCAO = {
    "preenchido": "Região preenchida",
    "contorno": "Contorno fino do alvo",
}

HOTKEYS_PAUSA = {
    "none": "Desativada",
    "f6": "Teclado — F6",
    "f7": "Teclado — F7",
    "f8": "Teclado — F8",
    "f9": "Teclado — F9",
    "f10": "Teclado — F10",
    "mouse4": "Mouse — botão lateral 1",
    "mouse5": "Mouse — botão lateral 2",
}

PERFIS_MOVIMENTO = {
    "reto_suave": ("Reto suave", 0.0, 0.075, 18, 0.0),
    "natural": ("Natural", 0.36, 0.075, 18, 0.15),
    "mao_tremula": ("Mão trêmula", 0.58, 0.12, 10, 0.55),
    "curvas_fortes": ("Curvas fortes", 0.82, 0.055, 30, 0.22),
    "personalizado": ("Personalizado", None, None, None, None),
}


PADRAO = {
    "cor_hex": "#0013FF",
    "modo_ativacao": "mirando",
    "modo_deteccao": "preenchido",
    "hotkey_pausa": "f8",
    "monitor_selecionado": "principal",
    "tolerancia_rgb": 70,
    # Perfil consolidado de resposta, inspirado na associação temporal do Prime Aim.
    "ganho": 0.35,
    "altura_puxada": 0,
    "offset_vertical_px": 0,
    "passo_maximo": 24,
    "zona_morta": 3,
    "filtro_alvo": 0.90,
    "confirmacoes_alvo": 1,
    "atraso_aquisicao_ms": 20,
    "rampa_movimento_ms": 45,
    "microtremor_px": 0.15,
    "humanizacao_forca": 0.36,
    "humanizacao_suavizacao": 0.075,
    "humanizacao_duracao": 18,
    "perfil_movimento": "natural",
    "teste_tracado_id": 0,
    "prioridade_centro": 0.85,
    "ignorar_barras": True,
    "ignorar_triangulos_invertidos": True,
    "distancia_reaquisicao": 140,
    "fov_diametro": 600,
    "zona_exclusao_diametro": 40,
    "taxa_alvo_hz": 165.0,
    "area_minima": 2,
    "modo_adaptativo": True,
    "detectar_longa_distancia": True,
}

PERFIL_PRIME = {
    "tolerancia_rgb": 70,
    "ganho": 0.35,
    "altura_puxada": 0,
    "offset_vertical_px": 0,
    "passo_maximo": 24,
    "zona_morta": 3,
    "filtro_alvo": 0.90,
    "confirmacoes_alvo": 1,
    "atraso_aquisicao_ms": 20,
    "rampa_movimento_ms": 45,
    "microtremor_px": 0.15,
    "prioridade_centro": 0.85,
    "ignorar_barras": True,
    "ignorar_triangulos_invertidos": True,
    "distancia_reaquisicao": 140,
    "zona_exclusao_diametro": 40,
    "area_minima": 2,
    "modo_adaptativo": True,
}


AJUDAS = {
    "modo_deteccao": (
        "Define como a região da cor encontrada será usada para localizar o alvo.\n\n"
        "Região preenchida: usa toda a área que corresponde à cor configurada. É o modo "
        "mais robusto quando o alvo tem preenchimento uniforme.\n\n"
        "Contorno fino do alvo: transforma a máscara da cor em uma linha periférica de "
        "aproximadamente um pixel e usa o contorno externo para calcular o centro. Isso "
        "é útil quando você quer ignorar o interior do alvo e seguir apenas a borda.\n\n"
        "O modo contorno não escolhe uma cor diferente: ele continua usando exclusivamente "
        "a Cor do alvo e a Tolerância configuradas."
    ),
    "monitor_selecionado": (
        "Escolhe a tela que será capturada. Monitor principal usa a resolução real "
        "da tela principal do Windows; os demais usam suas próprias coordenadas e "
        "resoluções; Janela ativa mantém o comportamento baseado na janela em foco.\n\n"
        "Se trocar a resolução, entrar em tela cheia, usar tela esticada ou mover a "
        "janela, o rastreador recalcula automaticamente o centro e o FOV."
    ),
    "pausa": (
        "Pausa imediatamente a captura e o envio de movimentos, mantendo o aplicativo aberto.\n\n"
        "Quando pausado: o cursor fica parado mesmo que os botões de ativação estejam pressionados.\n"
        "Quando ativado novamente: o rastreamento volta sem precisar reiniciar o programa."
    ),
    "hotkey_pausa": (
        "Define a tecla ou o botão lateral que alterna entre pausado e ativo.\n\n"
        "Escolha uma tecla F6–F10 ou um dos botões laterais do mouse.\n"
        "Pressione uma vez para pausar e pressione novamente para ativar.\n"
        "Use Desativada se preferir controlar somente pelo botão do painel."
    ),
    "modo_ativacao": (
        "Escolhe quais botões ativam a puxada.\n\n"
        "Mirando: ativa somente com o botão direito pressionado.\n"
        "Atirando: ativa somente com o botão esquerdo pressionado.\n"
        "Ambos: ativa quando qualquer um dos dois estiver pressionado.\n"
        "Mirando + atirando: ativa somente quando os dois estiverem pressionados ao mesmo tempo.\n\n"
        "Ao soltar o botão ou deixar de cumprir a condição escolhida, o movimento para "
        "imediatamente e o acumulador é zerado."
    ),
    "cor_hex": (
        "Define a cor que será procurada dentro do FOV. Use o formato hexadecimal "
        "#RRGGBB, por exemplo #0013FF. O rastreador compara cada canal RGB "
        "independentemente com a cor escolhida, aplicando a Tolerância configurada. "
        "Alterar para outra cor muda o alvo sem criar uma regra específica para azul, "
        "vermelho ou qualquer outra cor."
    ),
    "tolerancia_rgb": (
        "Define quanto a cor encontrada pode variar em cada canal RGB.\n\n"
        "Se aumentar: aceita mais variações de iluminação, brilho, antialiasing e "
        "distância, facilitando detectar o mesmo alvo quando ele fica menor ou mais escuro.\n\n"
        "Se diminuir: fica mais seletivo e reduz falsos positivos, mas pode deixar de "
        "detectar o alvo quando a aparência dele variar. Tolerância alta demais pode "
        "aceitar objetos visualmente parecidos."
    ),
    "area_minima": (
        "Define o tamanho mínimo da região colorida para ela ser considerada um alvo.\n\n"
        "Se aumentar: ignora pontos pequenos, partículas e ruído, mas pode ignorar uma "
        "bola distante que apareça com poucos pixels.\n\n"
        "Se diminuir: detecta alvos menores e distantes, porém fica mais sensível a "
        "pequenos artefatos da imagem."
    ),
    "ganho": (
        "Controla a intensidade proporcional da puxada em direção ao centro do FOV.\n\n"
        "Se aumentar: o cursor percorre mais pixels por atualização e chega mais rápido "
        "ao alvo, mas pode ficar agressivo, passar do ponto ou produzir mais correções.\n\n"
        "Se diminuir: o movimento fica mais suave e controlado, mas leva mais tempo para "
        "corrigir uma distância grande."
    ),
    "altura_puxada": (
        "Define a altura do ponto em que o cursor deve grudar, em pixels.\n\n"
        "0 px: centro vertical do FOV.\n"
        "Valor positivo: ponto abaixo do centro.\n"
        "Valor negativo: ponto acima do centro.\n\n"
        "Ele muda a coordenada Y de destino — não a força do movimento."
    ),
    "offset_vertical_px": (
        "Desloca o ponto vertical usado como referência, seguindo a lógica do Prime Aim.\n\n"
        "0 px: tenta levar o alvo ao centro vertical do FOV.\n"
        "Valor positivo: considera um ponto abaixo do centro como referência.\n"
        "Valor negativo: considera um ponto acima do centro como referência.\n\n"
        "Este controle é um offset em pixels, diferente da Altura da puxada, que é um multiplicador."
    ),
    "passo_maximo": (
        "Limita quantos pixels o Pro Micro pode mover em uma atualização.\n\n"
        "Se aumentar: corrige distâncias grandes mais rapidamente, mas cada atualização "
        "pode ficar mais brusca.\n\n"
        "Se diminuir: deixa cada passo menor e potencialmente mais suave, porém pode "
        "demorar mais para alcançar alvos afastados."
    ),
    "zona_morta": (
        "Cria uma pequena área ao redor do centro do FOV na qual nenhum movimento é enviado.\n\n"
        "Se aumentar: reduz tremor e microcorreções quando o alvo já está próximo do centro, "
        "mas pode deixar um pequeno erro final.\n\n"
        "Se diminuir: melhora a precisão final, mas pode causar pequenas correções contínuas "
        "quando a imagem oscila."
    ),
    "filtro_alvo": (
        "Controla quanto a posição nova do alvo influencia a posição filtrada.\n\n"
        "Se aumentar: acompanha mudanças de posição mais rapidamente e reduz atraso, mas "
        "pode transmitir mais ruído e deixar o cursor menos estável.\n\n"
        "Se diminuir: suaviza mais a posição e reduz tremores, porém acrescenta atraso ao "
        "acompanhar um alvo que se move rapidamente."
    ),
    "confirmacoes_alvo": (
        "Define quantos frames consecutivos precisam confirmar a mesma região antes de iniciar "
        "a puxada.\n\nSe aumentar: reduz ativações por ruído, mas acrescenta alguns milissegundos "
        "de espera. Se diminuir: responde mais rápido, porém fica mais sensível a aparições "
        "momentâneas."
    ),
    "atraso_aquisicao_ms": (
        "Adiciona uma espera curta depois da confirmação do alvo antes do primeiro movimento.\n\n"
        "Se aumentar: a resposta fica menos instantânea e mais gradual. Se diminuir: começa a "
        "corrigir mais rapidamente. Use valores baixos para não perder alvos pequenos."
    ),
    "rampa_movimento_ms": (
        "Controla quanto tempo a força da correção leva para chegar ao valor normal.\n\n"
        "Se aumentar: o começo fica mais suave, com menos tranco. Se diminuir: a correção entra "
        "mais rapidamente. A rampa não cria saltos nem ultrapassagem proposital."
    ),
    "microtremor_px": (
        "Adiciona uma microvariação contínua e limitada à trajetória para representar pequenas "
        "oscilações de uma mão no Paint.\n\nSe aumentar: a linha fica levemente mais irregular. "
        "Se diminuir: a trajetória fica mais reta. O valor é limitado para evitar zigue-zague "
        "ou deslocamentos aleatórios grandes."
    ),
    "humanizacao_forca": (
        "Controla a curvatura lateral criada diretamente pelo Pro Micro.\n\n"
        "0% mantém o trajeto reto; valores maiores criam arcos mais evidentes."
    ),
    "humanizacao_suavizacao": (
        "Define a rapidez com que a curva muda de direção. Menor gera arcos longos; "
        "maior deixa a trajetória mais viva."
    ),
    "humanizacao_duracao": (
        "Mantém a mesma tendência lateral por alguns ticks. Valores altos tornam os "
        "arcos mais longos e contínuos."
    ),
    "modo_adaptativo": (
        "Quando ativado, o rastreador ajusta automaticamente filtro, ganho, passo, rampa "
        "e atraso de aquisição conforme o tamanho e a distância do alvo detectado.\n\n"
        "Ativado: reduz a necessidade de ajustes manuais e usa uma resposta mais controlada "
        "para alvos pequenos ou distantes.\n"
        "Desativado: utiliza exatamente os valores configurados nos controles."
    ),
    "detectar_longa_distancia": (
        "Mantém a tolerância RGB escolhida, mas também reconhece a mesma família de cor "
        "quando o alvo distante fica escuro ou antialiasado. Usa matiz e saturação, "
        "junto com os filtros de forma e continuidade, para reduzir falsos positivos."
    ),
    "prioridade_centro": (
        "Define quanto a proximidade do centro do FOV pesa na escolha entre vários candidatos.\n\n"
        "Se aumentar: o alvo mais central vence com mais frequência, mesmo que outro tenha uma área maior.\n"
        "Se diminuir: a seleção considera mais a continuidade do alvo anterior e o tamanho da região.\n"
        "O valor recomendado para priorizar o centro fica entre 0,75 e 1,00."
    ),
    "ignorar_barras": (
        "Ignora regiões muito largas e baixas, como barras horizontais da interface.\n\n"
        "Quando ativado, rejeita candidatos com proporção de largura muito maior que a altura.\n"
        "Desative somente se o seu alvo legítimo tiver formato de barra."
    ),
    "ignorar_triangulos_invertidos": (
        "Ignora contornos aproximadamente triangulares com a ponta voltada para baixo.\n\n"
        "É útil para rejeitar o marcador triangular mostrado nos exemplos.\n"
        "Desative se o alvo legítimo for um triângulo invertido."
    ),
    "distancia_reaquisicao": (
        "Define a distância máxima, em pixels do FOV, para reencontrar o mesmo alvo depois "
        "que ele foi perdido por um frame.\n\n"
        "Se aumentar: facilita continuar acompanhando um alvo que se deslocou rapidamente, "
        "mas pode trocar para outro objeto parecido mais distante.\n\n"
        "Se diminuir: evita trocas para objetos distantes, mas pode perder o alvo quando ele "
        "mudar de posição de forma rápida."
    ),
    "fov_diametro": (
        "Define o diâmetro do FOV circular central dentro da área cliente da janela ativa.\n\n"
        "Se aumentar: enxerga uma região maior e encontra alvos mais afastados do centro, "
        "mas aumenta o trabalho de captura e detecção.\n\n"
        "Se diminuir: reduz o processamento e concentra a detecção no centro, porém o alvo "
        "precisa entrar numa área menor para ser encontrado."
    ),
    "zona_exclusao_diametro": (
        "Define um círculo central que será ignorado dentro do FOV principal. É útil para "
        "desconsiderar a bolinha ou o ponto vermelho da mira no Paint.\n\n"
        "Se aumentar: uma área maior ao redor do centro será ignorada, evitando a mira, "
        "mas também poderá excluir alvos legítimos que estejam exatamente no centro.\n\n"
        "Se diminuir: mais área próxima do centro volta a ser analisada. Use 0 px para "
        "desativar a exclusão central. O círculo externo do FOV continua funcionando."
    ),
    "taxa_alvo_hz": (
        "Define a frequência desejada de captura, detecção e envio de movimento.\n\n"
        "Se aumentar: atualiza o alvo com mais frequência e pode deixar o movimento mais "
        "contínuo, mas aumenta o uso de CPU e a quantidade de comandos enviados.\n\n"
        "Se diminuir: reduz o uso de recursos, mas deixa as atualizações mais espaçadas e pode "
        "aumentar a sensação de atraso. O sistema está preparado para trabalhar próximo de 165 Hz."
    ),
}



