from .rastreador import obter_base_dir

"""Painel gráfico para configurar e controlar o rastreador de cor."""

import json
import os
import subprocess
import sys
import time
import ctypes
from ctypes import wintypes
import tkinter as tk
import numpy as np
from pathlib import Path
from serial.tools import list_ports
from tkinter import messagebox, ttk

try:
    import mss
except ImportError:
    mss = None


BASE_DIR = obter_base_dir()
CONFIG_PATH = BASE_DIR / "config_rastreador.json"
PAUSA_PATH = BASE_DIR / "estado_pausa_rastreador.json"
TRACKER_PATH = BASE_DIR / "appgeral.py"
LOGS_DIR = BASE_DIR / "logs"
FIRMWARE_PATH = BASE_DIR / "firmware_pro_micro_humanizado_corrigido.ino"

from .painel_config import (
    AJUDAS, HOTKEYS_PAUSA, MODOS_ATIVACAO, MODOS_DETECCAO, PADRAO,
    PERFIL_PRIME, PERFIS_MOVIMENTO,
)

class PainelRastreador:
    def __init__(self, root):
        self.root = root
        self.root.title("Visão do Pro Micro")
        self.root.geometry("1450x760")
        self.root.minsize(1200, 680)
        self.root.protocol("WM_DELETE_WINDOW", self.fechar)

        self.processo_rastreador = None
        self.arquivo_log_saida = None
        self.arquivo_log_erro = None
        self.reiniciar_automaticamente = True
        self.tentativas_reinicio = 0
        self.inicio_rastreador = None
        self.pausa_estado_mtime = None
        self.pausado_var = tk.BooleanVar(value=False)
        self.autoaplicar_job = None
        self.suspender_autoaplicar = True
        self.opcoes_monitores = {}
        self.monitor_exibicao_var = tk.StringVar()
        self.escalas = {}
        self.rotulos_valor = {}
        self.cores_salvas = []
        self.lista_cores_salvas = None
        self.vars = {
            "cor_hex": tk.StringVar(value=PADRAO["cor_hex"]),
            "modo_ativacao": tk.StringVar(value=PADRAO["modo_ativacao"]),
            "modo_deteccao": tk.StringVar(value=PADRAO["modo_deteccao"]),
            "hotkey_pausa": tk.StringVar(value=PADRAO["hotkey_pausa"]),
            "monitor_selecionado": tk.StringVar(value=PADRAO["monitor_selecionado"]),
            "tolerancia_rgb": tk.IntVar(value=PADRAO["tolerancia_rgb"]),
            "ganho": tk.DoubleVar(value=PADRAO["ganho"]),
            "altura_puxada": tk.DoubleVar(value=PADRAO["altura_puxada"]),
            "offset_vertical_px": tk.IntVar(value=PADRAO["offset_vertical_px"]),
            "passo_maximo": tk.IntVar(value=PADRAO["passo_maximo"]),
            "zona_morta": tk.IntVar(value=PADRAO["zona_morta"]),
            "filtro_alvo": tk.DoubleVar(value=PADRAO["filtro_alvo"]),
            "confirmacoes_alvo": tk.IntVar(value=PADRAO["confirmacoes_alvo"]),
            "atraso_aquisicao_ms": tk.IntVar(value=PADRAO["atraso_aquisicao_ms"]),
            "rampa_movimento_ms": tk.IntVar(value=PADRAO["rampa_movimento_ms"]),
            "microtremor_px": tk.DoubleVar(value=PADRAO["microtremor_px"]),
            "humanizacao_forca": tk.DoubleVar(value=PADRAO["humanizacao_forca"]),
            "humanizacao_suavizacao": tk.DoubleVar(value=PADRAO["humanizacao_suavizacao"]),
            "humanizacao_duracao": tk.IntVar(value=PADRAO["humanizacao_duracao"]),
            "perfil_movimento": tk.StringVar(value=PADRAO["perfil_movimento"]),
            "teste_tracado_id": tk.IntVar(value=PADRAO["teste_tracado_id"]),
            "prioridade_centro": tk.DoubleVar(value=PADRAO["prioridade_centro"]),
            "ignorar_barras": tk.BooleanVar(value=PADRAO["ignorar_barras"]),
            "ignorar_triangulos_invertidos": tk.BooleanVar(
                value=PADRAO["ignorar_triangulos_invertidos"]
            ),
            "distancia_reaquisicao": tk.IntVar(
                value=PADRAO["distancia_reaquisicao"]
            ),
            "fov_diametro": tk.IntVar(value=PADRAO["fov_diametro"]),
            "zona_exclusao_diametro": tk.IntVar(
                value=PADRAO["zona_exclusao_diametro"]
            ),
            "taxa_alvo_hz": tk.DoubleVar(value=PADRAO["taxa_alvo_hz"]),
            "area_minima": tk.IntVar(value=PADRAO["area_minima"]),
            "modo_adaptativo": tk.BooleanVar(value=PADRAO["modo_adaptativo"]),
            "detectar_longa_distancia": tk.BooleanVar(
                value=PADRAO["detectar_longa_distancia"]
            ),
        }
        for variavel in self.vars.values():
            variavel.trace_add("write", self.agendar_aplicacao_automatica)

        self.status_var = tk.StringVar(value="Rastreador parado")
        self.modo_exibicao_var = tk.StringVar()
        self.modo_deteccao_exibicao_var = tk.StringVar()
        self.hotkey_pausa_exibicao_var = tk.StringVar()
        self.pausa_texto_var = tk.StringVar(value="Pausar rastreador")
        self.botao_pausa = None
        self.preview = None
        self.montar_interface()
        self.atualizar_monitores(silencioso=True)
        self.carregar_configuracao()
        self.carregar_estado_pausa()
        self.suspender_autoaplicar = False
        self.atualizar_preview()
        self.atualizar_status()
        self.monitorar_estado_pausa()

    def montar_interface(self):
        estilo = ttk.Style()
        try:
            estilo.theme_use("vista")
        except tk.TclError:
            pass

        principal = ttk.Frame(self.root, padding=16)
        principal.pack(fill="both", expand=True)
        for coluna in range(3):
            principal.columnconfigure(coluna, weight=1, uniform="colunas")

        titulo = ttk.Label(
            principal,
            text="Visão do Pro Micro",
            font=("Segoe UI", 18, "bold"),
        )
        titulo.grid(row=0, column=0, columnspan=3, sticky="w")
        subtitulo = ttk.Label(
            principal,
            text=(
                "Arraste as barras para ajustar. Passe o mouse sobre uma barra e use "
                "o scroll para ajuste fino. Clique em ? para entender cada função. "
                "Clique em Aplicar para gravar a configuração."
            ),
            wraplength=1400,
        )
        subtitulo.grid(row=1, column=0, columnspan=3, sticky="w", pady=(3, 12))

        grupo_cor = ttk.LabelFrame(principal, text="Cor e detecção", padding=10)
        grupo_cor.grid(
            row=2, column=0, sticky="nsew", padx=(0, 6), pady=(0, 10)
        )
        grupo_cor.columnconfigure(1, weight=1)

        ttk.Label(grupo_cor, text="Cor do alvo (hexadecimal):").grid(
            row=0, column=0, sticky="w", padx=(0, 8), pady=4
        )
        entrada_cor = ttk.Entry(
            grupo_cor, textvariable=self.vars["cor_hex"], width=14
        )
        entrada_cor.grid(row=0, column=1, sticky="w", pady=4)
        entrada_cor.bind("<KeyRelease>", lambda _evento: self.atualizar_preview())
        self.preview = tk.Label(
            grupo_cor,
            text=" prévia ",
            width=12,
            relief="sunken",
            bd=1,
        )
        self.preview.grid(row=0, column=2, sticky="e", padx=(10, 8), pady=4)
        self.adicionar_ajuda(grupo_cor, 0, "Cor do alvo", AJUDAS["cor_hex"])

        ttk.Button(
            grupo_cor,
            text="Canetinha: capturar cor",
            command=self.iniciar_captura_cor,
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(5, 3))
        ttk.Button(
            grupo_cor,
            text="Salvar cor",
            command=self.salvar_cor,
        ).grid(row=1, column=2, sticky="e", padx=(8, 8), pady=(5, 3))

        self.adicionar_trackbar(
            grupo_cor, 2, "Tolerância:", "tolerancia_rgb", 0, 100, 1
        )
        self.adicionar_trackbar(
            grupo_cor, 3, "Área mínima:", "area_minima", 1, 5000, 1
        )

        ttk.Label(grupo_cor, text="Modo de detecção:").grid(
            row=4, column=0, sticky="w", padx=(0, 8), pady=5
        )
        self.deteccao_combo = ttk.Combobox(
            grupo_cor,
            textvariable=self.modo_deteccao_exibicao_var,
            values=list(MODOS_DETECCAO.values()),
            state="readonly",
            width=31,
        )
        self.deteccao_combo.grid(row=4, column=1, sticky="w", pady=4)
        self.deteccao_combo.bind(
            "<<ComboboxSelected>>", self.selecionar_modo_deteccao
        )
        self.adicionar_ajuda(
            grupo_cor,
            4,
            "Modo de detecção",
            AJUDAS["modo_deteccao"],
        )
        ttk.Checkbutton(
            grupo_cor,
            text="Detectar cor distante (sem abrir RGB)",
            variable=self.vars["detectar_longa_distancia"],
        ).grid(row=5, column=0, columnspan=3, sticky="w", pady=(5, 2))
        self.adicionar_ajuda(
            grupo_cor, 5, "Detecção de longa distância", AJUDAS["detectar_longa_distancia"]
        )
        ttk.Label(grupo_cor, text="Cores salvas (clique para aplicar):").grid(
            row=6, column=0, columnspan=3, sticky="w", pady=(8, 2)
        )
        self.lista_cores_salvas = tk.Listbox(
            grupo_cor,
            height=4,
            exportselection=False,
            activestyle="none",
        )
        self.lista_cores_salvas.grid(
            row=7, column=0, columnspan=2, sticky="ew", pady=(0, 3)
        )
        self.lista_cores_salvas.bind("<<ListboxSelect>>", self.aplicar_cor_salva)
        ttk.Button(
            grupo_cor,
            text="Remover",
            command=self.remover_cor_salva,
        ).grid(row=7, column=2, sticky="n", padx=(8, 8), pady=(0, 3))

        grupo_movimento = ttk.LabelFrame(
            principal, text="Movimento e suavidade", padding=10
        )
        grupo_movimento.grid(
            row=2, column=1, sticky="nsew", padx=6, pady=(0, 10)
        )
        grupo_movimento.columnconfigure(1, weight=1)

        ttk.Label(grupo_movimento, text="Ativar puxada com:").grid(
            row=0, column=0, sticky="w", padx=(0, 8), pady=5
        )
        self.modo_combo = ttk.Combobox(
            grupo_movimento,
            textvariable=self.modo_exibicao_var,
            values=list(MODOS_ATIVACAO.values()),
            state="readonly",
            width=39,
        )
        self.modo_combo.grid(row=0, column=1, sticky="w", pady=4)
        self.modo_combo.bind("<<ComboboxSelected>>", self.selecionar_modo_ativacao)
        self.adicionar_ajuda(
            grupo_movimento,
            0,
            "Modo de ativação",
            AJUDAS["modo_ativacao"],
        )

        self.adicionar_trackbar(
            grupo_movimento, 1, "Velocidade / ganho:", "ganho", 0.01, 2.0, 0.01
        )
        self.adicionar_trackbar(
            grupo_movimento, 2, "Altura da puxada:", "altura_puxada", -400, 400, 1
        )
        self.adicionar_trackbar(
            grupo_movimento, 3, "Offset vertical do alvo:", "offset_vertical_px", -200, 200, 1
        )
        self.adicionar_ajuda(
            grupo_movimento, 3, "Offset vertical do alvo", AJUDAS["offset_vertical_px"]
        )
        self.adicionar_trackbar(
            grupo_movimento, 4, "Prioridade do centro:", "prioridade_centro", 0.0, 1.0, 0.05
        )
        self.adicionar_trackbar(
            grupo_movimento, 5, "Passo máximo:", "passo_maximo", 1, 100, 1
        )
        self.adicionar_trackbar(
            grupo_movimento, 6, "Zona morta:", "zona_morta", 0, 50, 1
        )
        self.adicionar_trackbar(
            grupo_movimento, 7, "Filtro do alvo:", "filtro_alvo", 0.01, 1.0, 0.01
        )
        self.adicionar_trackbar(
            grupo_movimento, 8, "Confirmações:", "confirmacoes_alvo", 1, 8, 1
        )
        self.adicionar_trackbar(
            grupo_movimento, 9, "Atraso de aquisição:", "atraso_aquisicao_ms", 0, 250, 5
        )
        self.adicionar_trackbar(
            grupo_movimento, 10, "Rampa inicial:", "rampa_movimento_ms", 0, 300, 5
        )
        self.adicionar_trackbar(
            grupo_movimento, 11, "Microvariação:", "microtremor_px", 0.0, 2.0, 0.05
        )
        ttk.Label(grupo_movimento, text="Perfil de movimento:").grid(
            row=12, column=0, sticky="w", padx=(0, 8), pady=5
        )
        self.perfil_movimento_var = tk.StringVar()
        self.perfil_combo = ttk.Combobox(
            grupo_movimento,
            textvariable=self.perfil_movimento_var,
            values=[item[0] for item in PERFIS_MOVIMENTO.values()],
            state="readonly",
            width=25,
        )
        self.perfil_combo.grid(row=12, column=1, sticky="w", pady=4)
        self.perfil_combo.bind("<<ComboboxSelected>>", self.aplicar_perfil_movimento)
        ttk.Button(
            grupo_movimento, text="Testar traço no Paint", command=self.solicitar_teste_tracado
        ).grid(row=12, column=2, columnspan=2, sticky="e", padx=(8, 2), pady=4)
        self.adicionar_trackbar(
            grupo_movimento, 13, "Força da curva:", "humanizacao_forca", 0.0, 1.0, 0.01
        )
        self.adicionar_trackbar(
            grupo_movimento, 14, "Mudança da curva:", "humanizacao_suavizacao", 0.01, 0.5, 0.005
        )
        self.adicionar_trackbar(
            grupo_movimento, 15, "Duração da curva:", "humanizacao_duracao", 1, 80, 1
        )
        ttk.Checkbutton(
            grupo_movimento,
            text="Ignorar barras horizontais",
            variable=self.vars["ignorar_barras"],
        ).grid(row=16, column=0, columnspan=2, sticky="w", pady=(6, 2))
        self.adicionar_ajuda(
            grupo_movimento, 16, "Ignorar barras horizontais", AJUDAS["ignorar_barras"]
        )
        ttk.Checkbutton(
            grupo_movimento,
            text="Ignorar triângulos invertidos",
            variable=self.vars["ignorar_triangulos_invertidos"],
        ).grid(row=17, column=0, columnspan=2, sticky="w", pady=2)
        self.adicionar_ajuda(
            grupo_movimento,
            17,
            "Ignorar triângulos invertidos",
            AJUDAS["ignorar_triangulos_invertidos"],
        )
        ttk.Checkbutton(
            grupo_movimento,
            text="Modo adaptativo (ajuste automático)",
            variable=self.vars["modo_adaptativo"],
        ).grid(row=18, column=0, columnspan=2, sticky="w", pady=(6, 2))
        self.adicionar_ajuda(
            grupo_movimento, 18, "Modo adaptativo", AJUDAS["modo_adaptativo"]
        )

        grupo_rastreamento = ttk.LabelFrame(
            principal, text="Rastreamento e FOV", padding=10
        )
        grupo_rastreamento.grid(
            row=2, column=2, sticky="nsew", padx=(6, 0), pady=(0, 10)
        )
        grupo_rastreamento.columnconfigure(1, weight=1)

        ttk.Label(grupo_rastreamento, text="Monitor de captura:").grid(
            row=0, column=0, sticky="w", padx=(0, 8), pady=5
        )
        self.monitor_combo = ttk.Combobox(
            grupo_rastreamento,
            textvariable=self.monitor_exibicao_var,
            state="readonly",
            width=31,
        )
        self.monitor_combo.grid(row=0, column=1, sticky="w", pady=4)
        self.monitor_combo.bind("<<ComboboxSelected>>", self.selecionar_monitor)
        ttk.Button(
            grupo_rastreamento,
            text="Atualizar",
            command=self.atualizar_monitores,
            width=10,
        ).grid(row=0, column=2, sticky="e", padx=(8, 8), pady=4)
        self.adicionar_ajuda(
            grupo_rastreamento,
            0,
            "Monitor de captura",
            AJUDAS["monitor_selecionado"],
        )

        self.adicionar_trackbar(
            grupo_rastreamento,
            1,
            "Distância de reaquisição:",
            "distancia_reaquisicao",
            20,
            500,
            5,
        )
        self.adicionar_trackbar(
            grupo_rastreamento, 2, "Diâmetro do FOV:", "fov_diametro", 100, 1600, 10
        )
        self.adicionar_trackbar(
            grupo_rastreamento,
            3,
            "Exclusão central:",
            "zona_exclusao_diametro",
            0,
            600,
            2,
        )
        self.adicionar_trackbar(
            grupo_rastreamento, 4, "Taxa desejada:", "taxa_alvo_hz", 30, 300, 1
        )

        grupo_controle = ttk.LabelFrame(
            principal, text="Controle geral", padding=10
        )
        grupo_controle.grid(
            row=3, column=0, columnspan=3, sticky="ew", pady=(0, 8)
        )
        grupo_controle.columnconfigure(2, weight=1)
        self.botao_pausa = ttk.Button(
            grupo_controle,
            textvariable=self.pausa_texto_var,
            command=self.alternar_pausa,
            width=20,
        )
        self.botao_pausa.grid(row=0, column=0, sticky="w", padx=(0, 10), pady=3)
        ttk.Label(grupo_controle, text="Hotkey pausa/ativar:").grid(
            row=0, column=1, sticky="w", padx=(0, 8), pady=3
        )
        self.hotkey_combo = ttk.Combobox(
            grupo_controle,
            textvariable=self.hotkey_pausa_exibicao_var,
            values=list(HOTKEYS_PAUSA.values()),
            state="readonly",
            width=29,
        )
        self.hotkey_combo.grid(row=0, column=2, sticky="w", pady=3)
        self.hotkey_combo.bind(
            "<<ComboboxSelected>>", self.selecionar_hotkey_pausa
        )
        self.adicionar_ajuda(
            grupo_controle, 0, "Pausar / ativar", AJUDAS["pausa"], coluna=3
        )
        self.adicionar_ajuda(
            grupo_controle, 0, "Hotkey de pausa", AJUDAS["hotkey_pausa"], coluna=4
        )

        botoes = ttk.Frame(principal)
        botoes.grid(
            row=4, column=0, columnspan=3, sticky="ew", pady=(2, 8)
        )
        ttk.Button(
            botoes, text="Aplicar configuração", command=self.aplicar
        ).pack(side="left", padx=(0, 6))
        ttk.Button(
            botoes,
            text="Perfil Prime Aim",
            command=self.aplicar_perfil_prime,
        ).pack(side="left", padx=6)
        ttk.Button(botoes, text="Iniciar rastreador", command=self.iniciar).pack(
            side="left", padx=6
        )
        ttk.Button(botoes, text="Parar rastreador", command=self.parar).pack(
            side="left", padx=6
        )
        ttk.Button(
            botoes,
            text="Abrir firmware .ino atualizado",
            command=self.abrir_firmware,
        ).pack(side="left", padx=6)
        ttk.Button(
            botoes, text="Recarregar", command=self.carregar_configuracao
        ).pack(side="right")

        status_frame = ttk.LabelFrame(principal, text="Status", padding=10)
        status_frame.grid(
            row=5, column=0, columnspan=3, sticky="ew", pady=(0, 8)
        )
        ttk.Label(status_frame, textvariable=self.status_var).pack(anchor="w")
        ttk.Label(
            status_frame,
            text=(
                "FOV circular do monitor selecionado   |   Porta fixa: COM11   |   "
                "O monitor é recalculado automaticamente quando sua resolução muda"
            ),
            foreground="#555555",
        ).pack(anchor="w", pady=(4, 0))

        ajuda = ttk.Label(
            principal,
            text=(
                "Dica: o scroll altera uma unidade por movimento. Para uma mudança "
                "maior, arraste a barra; para uma mudança precisa, use o scroll. "
                "As alterações são aplicadas automaticamente após uma pequena pausa; "
                "Aplicar continua disponível para salvar imediatamente. Use Pausar "
                "quando quiser mexer no PC sem enviar movimento."
            ),
            wraplength=1400,
            foreground="#555555",
        )
        ajuda.grid(
            row=6, column=0, columnspan=3, sticky="w", pady=(3, 0)
        )

    def obter_opcoes_monitores(self):
        opcoes = {}
        opcoes["janela_ativa"] = "Janela ativa (compatibilidade)"
        if mss is None:
            opcoes["principal"] = "Monitor principal (MSS indisponível)"
            return opcoes
        try:
            with mss.MSS() as captura:
                monitores = captura.monitors[1:]
        except Exception:
            opcoes["principal"] = "Monitor principal (não foi possível listar)"
            return opcoes

        indice_principal = 1
        for indice, monitor in enumerate(monitores, start=1):
            if monitor.get("is_primary"):
                indice_principal = indice
                break

        for indice, monitor in enumerate(monitores, start=1):
            largura = int(monitor.get("width", 0))
            altura = int(monitor.get("height", 0))
            esquerda = int(monitor.get("left", 0))
            topo = int(monitor.get("top", 0))
            principal = indice == indice_principal
            chave = "principal" if principal else str(indice)
            nome = "Monitor principal" if principal else f"Monitor {indice}"
            opcoes[chave] = (
                f"{nome} — {largura}x{altura} ({esquerda},{topo})"
            )
        return opcoes

    def atualizar_monitores(self, silencioso=False):
        anterior = self.vars["monitor_selecionado"].get()
        self.opcoes_monitores = self.obter_opcoes_monitores()
        self.monitor_combo["values"] = list(self.opcoes_monitores.values())
        if anterior not in self.opcoes_monitores:
            anterior = "principal" if "principal" in self.opcoes_monitores else next(
                iter(self.opcoes_monitores), "janela_ativa"
            )
        self.vars["monitor_selecionado"].set(anterior)
        self.atualizar_monitor_exibicao()
        if not silencioso:
            self.status_var.set("Lista de monitores atualizada; clique em Aplicar")

    def monitor_interno_atual(self):
        exibido = self.monitor_exibicao_var.get()
        for interno, rotulo in self.opcoes_monitores.items():
            if rotulo == exibido:
                return interno
        atual = self.vars["monitor_selecionado"].get()
        return atual if atual in self.opcoes_monitores else "principal"

    def selecionar_monitor(self, _evento=None):
        self.vars["monitor_selecionado"].set(self.monitor_interno_atual())

    def atualizar_monitor_exibicao(self):
        interno = self.vars["monitor_selecionado"].get()
        if interno not in self.opcoes_monitores:
            interno = "principal" if "principal" in self.opcoes_monitores else next(
                iter(self.opcoes_monitores), "janela_ativa"
            )
            self.vars["monitor_selecionado"].set(interno)
        self.monitor_exibicao_var.set(self.opcoes_monitores.get(interno, interno))

    def modo_deteccao_interno_atual(self):
        exibido = self.modo_deteccao_exibicao_var.get()
        for interno, rotulo in MODOS_DETECCAO.items():
            if rotulo == exibido:
                return interno
        atual = self.vars["modo_deteccao"].get()
        return atual if atual in MODOS_DETECCAO else "preenchido"

    def selecionar_modo_deteccao(self, _evento=None):
        self.vars["modo_deteccao"].set(self.modo_deteccao_interno_atual())

    def atualizar_modo_deteccao_exibicao(self):
        interno = self.vars["modo_deteccao"].get()
        if interno not in MODOS_DETECCAO:
            interno = "preenchido"
            self.vars["modo_deteccao"].set(interno)
        self.modo_deteccao_exibicao_var.set(MODOS_DETECCAO[interno])

    def atualizar_perfil_movimento_exibicao(self):
        interno = self.vars["perfil_movimento"].get()
        if interno not in PERFIS_MOVIMENTO:
            interno = "personalizado"
            self.vars["perfil_movimento"].set(interno)
        self.perfil_movimento_var.set(PERFIS_MOVIMENTO[interno][0])

    def aplicar_perfil_movimento(self, _evento=None):
        escolhido = self.perfil_movimento_var.get()
        interno = next(
            (nome for nome, dados in PERFIS_MOVIMENTO.items() if dados[0] == escolhido),
            "personalizado",
        )
        valores = PERFIS_MOVIMENTO[interno]
        self.suspender_autoaplicar = True
        try:
            self.vars["perfil_movimento"].set(interno)
            if interno != "personalizado":
                for nome, valor in zip(
                    ("humanizacao_forca", "humanizacao_suavizacao", "humanizacao_duracao", "microtremor_px"),
                    valores[1:],
                ):
                    self.vars[nome].set(valor)
            self.atualizar_valores_exibidos()
            self.salvar_configuracao()
            self.status_var.set(f"Perfil aplicado: {valores[0]}")
        except (ValueError, OSError) as erro:
            self.status_var.set(f"Não foi possível aplicar o perfil: {erro}")
        finally:
            self.suspender_autoaplicar = False

    def solicitar_teste_tracado(self):
        """Agenda um teste que o rastreador enviará pela porta já aberta."""
        try:
            self.vars["teste_tracado_id"].set(int(time.time_ns() % 2_000_000_000))
            self.salvar_configuracao()
        except (ValueError, OSError) as erro:
            messagebox.showerror("Teste não iniciado", str(erro), parent=self.root)
            return
        self.status_var.set("Teste agendado: deixe o Paint em foco; começa em 2 segundos.")
        messagebox.showinfo(
            "Teste de traçado",
            "Feche esta mensagem e deixe o Paint em foco. O Pro Micro começará o desenho em até 2,5 segundos.",
            parent=self.root,
        )

    def agendar_aplicacao_automatica(self, *_args):
        """Aplica alterações depois que o usuário termina um ajuste contínuo."""
        if self.suspender_autoaplicar:
            return
        if self.autoaplicar_job is not None:
            try:
                self.root.after_cancel(self.autoaplicar_job)
            except tk.TclError:
                pass
        self.status_var.set("Alteração detectada; aguardando confirmação...")
        self.autoaplicar_job = self.root.after(350, self.aplicar_automaticamente)

    def aplicar_automaticamente(self):
        self.autoaplicar_job = None
        try:
            dados = self.salvar_configuracao()
        except (ValueError, OSError) as erro:
            # Durante a digitação da cor, o texto pode ficar temporariamente
            # incompleto. Nesse caso, aguarda a próxima alteração sem pop-up.
            self.status_var.set(f"Aguardando valor válido: {erro}")
            return
        self.atualizar_preview()
        self.status_var.set(
            f"Aplicado automaticamente: {dados['cor_hex']} | "
            f"ganho {dados['ganho']:.2f} | tolerância ±{dados['tolerancia_rgb']}"
        )

    def adicionar_trackbar(
        self, parent, row, rotulo, nome, minimo, maximo, incremento
    ):
        ttk.Label(parent, text=rotulo).grid(
            row=row, column=0, sticky="w", padx=(0, 8), pady=5
        )

        escala = tk.Scale(
            parent,
            from_=minimo,
            to=maximo,
            orient="horizontal",
            resolution=incremento,
            showvalue=0,
            variable=self.vars[nome],
            length=230,
            sliderlength=18,
            highlightthickness=0,
            bd=0,
            relief="flat",
            command=lambda _valor, parametro=nome: self.atualizar_rotulo(
                parametro
            ),
        )
        escala.grid(row=row, column=1, sticky="ew", pady=2)
        self.escalas[nome] = escala

        rotulo_valor = ttk.Label(parent, width=14, anchor="e")
        rotulo_valor.grid(row=row, column=2, sticky="e", padx=(8, 8), pady=5)
        self.rotulos_valor[nome] = rotulo_valor

        self.adicionar_ajuda(parent, row, self.rotulo_curto(rotulo), AJUDAS[nome])

        for widget in (escala, rotulo_valor):
            widget.bind(
                "<MouseWheel>",
                lambda evento, parametro=nome, passo=incremento: self.ajustar_scroll(
                    evento, parametro, minimo, maximo, passo
                ),
            )
            widget.bind(
                "<Button-4>",
                lambda evento, parametro=nome, passo=incremento: self.ajustar_scroll(
                    evento, parametro, minimo, maximo, passo
                ),
            )
            widget.bind(
                "<Button-5>",
                lambda evento, parametro=nome, passo=incremento: self.ajustar_scroll(
                    evento, parametro, minimo, maximo, passo
                ),
            )
        self.atualizar_rotulo(nome)

    @staticmethod
    def rotulo_curto(rotulo):
        return rotulo.rstrip(":")

    def adicionar_ajuda(self, parent, row, titulo, texto, coluna=3):
        ttk.Button(
            parent,
            text="?",
            width=3,
            command=lambda: self.mostrar_ajuda(titulo, texto),
        ).grid(row=row, column=coluna, sticky="e", padx=(0, 2), pady=3)

    def mostrar_ajuda(self, titulo, texto):
        messagebox.showinfo(
            f"Ajuda — {titulo}",
            texto,
            parent=self.root,
        )

    def ajustar_scroll(self, evento, nome, minimo, maximo, incremento):
        if getattr(evento, "num", None) == 4:
            direcao = 1
        elif getattr(evento, "num", None) == 5:
            direcao = -1
        else:
            direcao = 1 if getattr(evento, "delta", 0) > 0 else -1

        atual = float(self.vars[nome].get())
        novo = max(minimo, min(maximo, atual + direcao * incremento))
        if incremento < 1:
            novo = round(novo, 2)
        else:
            novo = int(round(novo))
        self.vars[nome].set(novo)
        self.atualizar_rotulo(nome)
        return "break"

    def formatar_valor(self, nome):
        valor = self.vars[nome].get()
        if nome == "ganho":
            return f"{float(valor):.2f}x"
        if nome == "altura_puxada":
            return f"{int(float(valor))} px"
        if nome == "offset_vertical_px":
            return f"{int(float(valor))} px"
        if nome == "prioridade_centro":
            return f"{float(valor):.0%}"
        if nome == "filtro_alvo":
            return f"{float(valor):.2f}"
        if nome == "microtremor_px":
            return f"{float(valor):.2f} px"
        if nome == "humanizacao_forca":
            return f"{float(valor):.0%}"
        if nome == "humanizacao_suavizacao":
            return f"{float(valor):.3f}"
        if nome == "humanizacao_duracao":
            return f"{int(float(valor))} ticks"
        if nome in {"atraso_aquisicao_ms", "rampa_movimento_ms"}:
            return f"{int(float(valor))} ms"
        if nome == "taxa_alvo_hz":
            return f"{float(valor):.0f} Hz"
        if nome == "area_minima":
            return f"{int(float(valor))} px²"
        if nome in {"fov_diametro", "zona_exclusao_diametro"}:
            return f"{int(float(valor))} px"
        if nome in {"passo_maximo", "zona_morta", "distancia_reaquisicao"}:
            return f"{int(float(valor))} px"
        if nome == "confirmacoes_alvo":
            return f"{int(float(valor))} frames"
        if nome == "tolerancia_rgb":
            return f"±{int(float(valor))}"
        return str(valor)

    def atualizar_rotulo(self, nome):
        rotulo = self.rotulos_valor.get(nome)
        if rotulo is not None:
            rotulo.configure(text=self.formatar_valor(nome))

    def atualizar_valores_exibidos(self):
        for nome in self.rotulos_valor:
            self.atualizar_rotulo(nome)

    def ler_valores(self):
        def inteiro(nome, minimo, maximo):
            valor = int(float(self.vars[nome].get()))
            if not minimo <= valor <= maximo:
                raise ValueError(f"{nome} fora do intervalo permitido.")
            return valor

        def decimal(nome, minimo, maximo):
            valor = float(self.vars[nome].get())
            if not minimo <= valor <= maximo:
                raise ValueError(f"{nome} fora do intervalo permitido.")
            return valor

        cor = self.vars["cor_hex"].get().strip().upper()
        # String vazia é permitida e representa rastreamento desativado até que
        # o usuário informe uma cor válida.
        if cor and not self.cor_valida(cor):
            raise ValueError("A cor deve estar no formato #RRGGBB.")
        return {
            "porta": self.obter_porta_rastreador() or "COM11",
            "baudrate": 115200,
            "cor_hex": cor,
            "modo_ativacao": self.modo_interno_atual(),
            "modo_deteccao": self.modo_deteccao_interno_atual(),
            "hotkey_pausa": self.hotkey_pausa_interno_atual(),
            "monitor_selecionado": self.monitor_interno_atual(),
            "tolerancia_rgb": inteiro("tolerancia_rgb", 0, 100),
            "ganho": decimal("ganho", 0.01, 2.0),
            "altura_puxada": inteiro("altura_puxada", -400, 400),
            "offset_vertical_px": inteiro("offset_vertical_px", -200, 200),
            "passo_maximo": inteiro("passo_maximo", 1, 100),
            "zona_morta": inteiro("zona_morta", 0, 50),
            "filtro_alvo": decimal("filtro_alvo", 0.01, 1.0),
            "confirmacoes_alvo": inteiro("confirmacoes_alvo", 1, 8),
            "atraso_aquisicao_ms": inteiro("atraso_aquisicao_ms", 0, 250),
            "rampa_movimento_ms": inteiro("rampa_movimento_ms", 0, 300),
            "microtremor_px": decimal("microtremor_px", 0.0, 2.0),
            "humanizacao_forca": decimal("humanizacao_forca", 0.0, 1.0),
            "humanizacao_suavizacao": decimal("humanizacao_suavizacao", 0.01, 0.5),
            "humanizacao_duracao": inteiro("humanizacao_duracao", 1, 80),
            "perfil_movimento": self.vars["perfil_movimento"].get(),
            "teste_tracado_id": int(self.vars["teste_tracado_id"].get()),
            "prioridade_centro": decimal("prioridade_centro", 0.0, 1.0),
            "ignorar_barras": bool(self.vars["ignorar_barras"].get()),
            "ignorar_triangulos_invertidos": bool(
                self.vars["ignorar_triangulos_invertidos"].get()
            ),
            "distancia_reaquisicao": inteiro(
                "distancia_reaquisicao", 20, 500
            ),
            "fov_diametro": inteiro("fov_diametro", 100, 1600),
            "zona_exclusao_diametro": inteiro(
                "zona_exclusao_diametro", 0, 600
            ),
            "taxa_alvo_hz": decimal("taxa_alvo_hz", 30, 300),
            "area_minima": inteiro("area_minima", 1, 5000),
            "modo_adaptativo": bool(self.vars["modo_adaptativo"].get()),
            "detectar_longa_distancia": bool(
                self.vars["detectar_longa_distancia"].get()
            ),
        }

    @staticmethod
    def cor_valida(cor):
        if len(cor) != 7 or not cor.startswith("#"):
            return False
        try:
            int(cor[1:], 16)
            return True
        except ValueError:
            return False

    def salvar_configuracao(self):
        dados = self.ler_valores()
        dados["cores_salvas"] = list(self.cores_salvas)
        temporario = CONFIG_PATH.with_suffix(".tmp")
        temporario.write_text(
            json.dumps(dados, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        os.replace(temporario, CONFIG_PATH)
        return dados

    def abrir_firmware(self):
        """Abre o arquivo .ino versionado distribuído com o painel."""
        if not FIRMWARE_PATH.exists():
            self.status_var.set("Firmware atualizado não encontrado na instalação.")
            return
        try:
            os.startfile(str(FIRMWARE_PATH))
            self.status_var.set(f"Firmware aberto: {FIRMWARE_PATH.name}")
        except OSError as erro:
            self.status_var.set(f"Não foi possível abrir o firmware: {erro}")

    def aplicar_perfil_prime(self):
        """Aplica o conjunto consolidado sem alterar cor, monitor ou ativação."""
        self.suspender_autoaplicar = True
        try:
            for nome, valor in PERFIL_PRIME.items():
                self.vars[nome].set(valor)
            self.atualizar_valores_exibidos()
            dados = self.salvar_configuracao()
            self.status_var.set(
                f"Perfil Prime Aim aplicado: ganho {dados['ganho']:.2f} | "
                f"tolerância ±{dados['tolerancia_rgb']}"
            )
        except (ValueError, OSError) as erro:
            self.status_var.set(f"Não foi possível aplicar o perfil: {erro}")
        finally:
            self.suspender_autoaplicar = False

    def modo_interno_atual(self):
        exibido = self.modo_exibicao_var.get()
        for interno, rotulo in MODOS_ATIVACAO.items():
            if rotulo == exibido:
                return interno
        modo = self.vars["modo_ativacao"].get()
        return modo if modo in MODOS_ATIVACAO else PADRAO["modo_ativacao"]

    def selecionar_modo_ativacao(self, _evento=None):
        self.vars["modo_ativacao"].set(self.modo_interno_atual())

    def atualizar_modo_exibicao(self):
        modo = self.vars["modo_ativacao"].get()
        if modo not in MODOS_ATIVACAO:
            modo = PADRAO["modo_ativacao"]
            self.vars["modo_ativacao"].set(modo)
        self.modo_exibicao_var.set(MODOS_ATIVACAO[modo])

    def hotkey_pausa_interno_atual(self):
        exibido = self.hotkey_pausa_exibicao_var.get()
        for interno, rotulo in HOTKEYS_PAUSA.items():
            if rotulo == exibido:
                return interno
        atual = self.vars["hotkey_pausa"].get()
        return atual if atual in HOTKEYS_PAUSA else PADRAO["hotkey_pausa"]

    def selecionar_hotkey_pausa(self, _evento=None):
        self.vars["hotkey_pausa"].set(self.hotkey_pausa_interno_atual())

    def atualizar_hotkey_pausa_exibicao(self):
        interno = self.vars["hotkey_pausa"].get()
        if interno not in HOTKEYS_PAUSA:
            interno = PADRAO["hotkey_pausa"]
            self.vars["hotkey_pausa"].set(interno)
        self.hotkey_pausa_exibicao_var.set(HOTKEYS_PAUSA[interno])

    def salvar_estado_pausa(self):
        temporario = PAUSA_PATH.with_suffix(".tmp")
        temporario.write_text(
            json.dumps({"pausado": bool(self.pausado_var.get())}) + "\n",
            encoding="utf-8",
        )
        os.replace(temporario, PAUSA_PATH)
        try:
            self.pausa_estado_mtime = PAUSA_PATH.stat().st_mtime_ns
        except OSError:
            self.pausa_estado_mtime = None

    def carregar_estado_pausa(self):
        try:
            dados = json.loads(PAUSA_PATH.read_text(encoding="utf-8"))
            pausado = bool(dados.get("pausado", False))
        except (FileNotFoundError, OSError, json.JSONDecodeError):
            pausado = False
        self.pausado_var.set(pausado)
        self.atualizar_pausa_exibicao()
        try:
            self.pausa_estado_mtime = PAUSA_PATH.stat().st_mtime_ns
        except OSError:
            self.pausa_estado_mtime = None

    def atualizar_pausa_exibicao(self):
        if self.pausado_var.get():
            self.pausa_texto_var.set("Ativar rastreador")
        else:
            self.pausa_texto_var.set("Pausar rastreador")

    def alternar_pausa(self):
        self.pausado_var.set(not self.pausado_var.get())
        try:
            self.salvar_estado_pausa()
        except OSError as erro:
            messagebox.showerror("Falha ao salvar pausa", str(erro))
            return
        self.atualizar_pausa_exibicao()
        self.status_var.set(
            "Rastreador pausado — captura e movimento desativados"
            if self.pausado_var.get()
            else "Rastreador ativado — pronto para rastrear"
        )

    def monitorar_estado_pausa(self):
        try:
            mtime = PAUSA_PATH.stat().st_mtime_ns
        except OSError:
            mtime = None
        if mtime != self.pausa_estado_mtime:
            self.carregar_estado_pausa()
        self.atualizar_pausa_exibicao()
        self.root.after(250, self.monitorar_estado_pausa)

    def carregar_configuracao(self):
        if self.autoaplicar_job is not None:
            try:
                self.root.after_cancel(self.autoaplicar_job)
            except tk.TclError:
                pass
            self.autoaplicar_job = None
        anterior = self.suspender_autoaplicar
        self.suspender_autoaplicar = True
        try:
            try:
                dados = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            except (FileNotFoundError, OSError, json.JSONDecodeError):
                dados = PADRAO.copy()
            self.cores_salvas = self.normalizar_cores_salvas(
                dados.get("cores_salvas", [dados.get("cor_hex", PADRAO["cor_hex"])])
            )
            for nome, padrao in PADRAO.items():
                self.vars[nome].set(dados.get(nome, padrao))
            self.atualizar_monitor_exibicao()
            self.atualizar_modo_exibicao()
            self.atualizar_modo_deteccao_exibicao()
            self.atualizar_perfil_movimento_exibicao()
            self.atualizar_hotkey_pausa_exibicao()
            self.atualizar_valores_exibidos()
            self.atualizar_lista_cores_salvas()
            self.atualizar_preview()
            self.status_var.set("Configuração carregada")
        finally:
            self.suspender_autoaplicar = anterior

    def aplicar(self):
        if self.autoaplicar_job is not None:
            try:
                self.root.after_cancel(self.autoaplicar_job)
            except tk.TclError:
                pass
            self.autoaplicar_job = None
        try:
            dados = self.salvar_configuracao()
        except (ValueError, OSError) as erro:
            messagebox.showerror("Configuração inválida", str(erro))
            return
        self.atualizar_preview()
        self.status_var.set(
            f"Aplicado: {dados['cor_hex']} | tolerância ±{dados['tolerancia_rgb']} | "
            f"ganho {dados['ganho']:.2f}"
        )

    def atualizar_preview(self):
        cor = self.vars["cor_hex"].get().strip()
        if self.cor_valida(cor):
            self.preview.configure(bg=cor)
        else:
            self.preview.configure(bg="#d9d9d9")

    @classmethod
    def normalizar_cores_salvas(cls, cores):
        """Mantém uma paleta curta, válida e sem duplicatas."""
        if not isinstance(cores, list):
            cores = []
        resultado = []
        for cor in cores:
            texto = str(cor).strip().upper()
            if cls.cor_valida(texto) and texto not in resultado:
                resultado.append(texto)
            if len(resultado) >= 16:
                break
        return resultado

    def atualizar_lista_cores_salvas(self):
        if self.lista_cores_salvas is None:
            return
        self.lista_cores_salvas.delete(0, tk.END)
        for cor in self.cores_salvas:
            self.lista_cores_salvas.insert(tk.END, cor)

    def aplicar_cor_salva(self, _evento=None):
        if self.lista_cores_salvas is None:
            return
        selecionados = self.lista_cores_salvas.curselection()
        if not selecionados:
            return
        cor = self.cores_salvas[selecionados[0]]
        anterior = self.suspender_autoaplicar
        self.suspender_autoaplicar = True
        try:
            self.vars["cor_hex"].set(cor)
            dados = self.salvar_configuracao()
            self.atualizar_preview()
        except (ValueError, OSError) as erro:
            self.status_var.set(f"Não foi possível aplicar a cor: {erro}")
            return
        finally:
            self.suspender_autoaplicar = anterior
        self.status_var.set(f"Cor aplicada ao alvo: {dados['cor_hex']}")

    def remover_cor_salva(self):
        if self.lista_cores_salvas is None:
            return
        selecionados = self.lista_cores_salvas.curselection()
        if not selecionados:
            self.status_var.set("Selecione uma cor salva para removê-la.")
            return
        cor = self.cores_salvas.pop(selecionados[0])
        try:
            self.salvar_configuracao()
        except (ValueError, OSError) as erro:
            self.status_var.set(f"Não foi possível remover a cor: {erro}")
            return
        self.atualizar_lista_cores_salvas()
        self.status_var.set(f"Cor removida da lista: {cor}")

    def iniciar_captura_cor(self):
        """Permite posicionar o cursor antes de ler exatamente um pixel da tela."""
        if mss is None:
            messagebox.showerror(
                "Canetinha indisponível",
                "A biblioteca mss não está instalada para ler o pixel da tela.",
                parent=self.root,
            )
            return
        self.status_var.set(
            "Canetinha ativa: posicione o cursor sobre a cor; captura em 2 segundos..."
        )
        self.root.after(2000, self.capturar_cor_sob_cursor)

    def capturar_cor_sob_cursor(self):
        """Lê um único pixel da tela na posição global atual do cursor."""
        ponto = wintypes.POINT()
        if not ctypes.windll.user32.GetCursorPos(ctypes.byref(ponto)):
            self.status_var.set("Não foi possível obter a posição da canetinha.")
            return
        try:
            with mss.mss() as captura:
                pixel_bgra = np.asarray(
                    captura.grab(
                        {"left": ponto.x, "top": ponto.y, "width": 1, "height": 1}
                    )
                )[0, 0]
            azul, verde, vermelho = (int(valor) for valor in pixel_bgra[:3])
        except Exception as erro:
            self.status_var.set(f"Falha ao capturar a cor: {erro}")
            return

        # A canetinha só preenche o campo. O usuário confirma com Salvar cor,
        # evitando trocar o alvo acidentalmente ao clicar na ferramenta.
        anterior = self.suspender_autoaplicar
        self.suspender_autoaplicar = True
        try:
            self.vars["cor_hex"].set(f"#{vermelho:02X}{verde:02X}{azul:02X}")
            self.atualizar_preview()
        finally:
            self.suspender_autoaplicar = anterior
        self.status_var.set(
            f"Cor capturada: #{vermelho:02X}{verde:02X}{azul:02X}. Clique em Salvar cor para usar."
        )

    def salvar_cor(self):
        """Aplica a cor atual e a coloca na paleta persistente."""
        try:
            cor = self.vars["cor_hex"].get().strip().upper()
            if not self.cor_valida(cor):
                raise ValueError("A cor deve estar no formato #RRGGBB.")
            if cor in self.cores_salvas:
                self.cores_salvas.remove(cor)
            self.cores_salvas.insert(0, cor)
            self.cores_salvas = self.cores_salvas[:16]
            dados = self.salvar_configuracao()
        except (ValueError, OSError) as erro:
            messagebox.showerror("Cor inválida", str(erro), parent=self.root)
            return
        self.atualizar_preview()
        self.atualizar_lista_cores_salvas()
        self.status_var.set(f"Cor salva na lista e aplicada ao rastreador: {dados['cor_hex']}")

    def encerrar_rastreadores_antigos(self):
        """Garante que só exista um rastreador usando a porta Serial."""
        if os.name != "nt":
            return
        comando = (
            "$ps = Get-CimInstance Win32_Process "
            "-Filter \"Name = 'python.exe' OR Name = 'pythonw.exe' OR Name = 'visao_pro_micro.exe'\"; "
            "$ps | Where-Object { $_.CommandLine -like "
            "'*appgeral.py* --tracker*' -or $_.CommandLine -like "
            "'*visao_pro_micro.exe* --tracker*' } | "
            "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
        )
        subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", comando],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

    @staticmethod
    def portas_seriais_disponiveis():
        """Retorna as portas seriais presentes no Windows no momento."""
        return list(list_ports.comports())

    def obter_porta_rastreador(self):
        """Usa a porta configurada ou localiza automaticamente a placa Arduino."""
        try:
            configuracao = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (FileNotFoundError, OSError, json.JSONDecodeError):
            configuracao = {}

        porta_configurada = str(configuracao.get("porta", "")).upper()
        portas = self.portas_seriais_disponiveis()
        por_nome = {porta.device.upper(): porta for porta in portas}
        if porta_configurada in por_nome:
            return por_nome[porta_configurada].device

        candidatas = [
            porta
            for porta in portas
            if any(
                termo in f"{porta.description} {porta.manufacturer or ''}".lower()
                for termo in ("arduino", "leonardo", "pro micro")
            )
        ]
        if len(candidatas) == 1:
            return candidatas[0].device
        return None

    def mensagem_porta_indisponivel(self):
        portas = self.portas_seriais_disponiveis()
        lista = ", ".join(porta.device for porta in portas) or "nenhuma porta serial"
        return (
            "Não encontrei o Arduino/Pro Micro conectado. "
            f"Portas disponíveis: {lista}.\n\n"
            "Conecte a placa ou confira a porta no Gerenciador de Dispositivos."
        )

    def iniciar(self, automatico=False):
        if not automatico:
            self.reiniciar_automaticamente = True
            self.tentativas_reinicio = 0

        # O JSON só é alterado pelo botão "Aplicar configuração". Isso evita
        # que o início automático ou o watchdog sobrescrevam o que foi carregado
        # do arquivo com valores antigos mantidos na interface.
        if self.processo_rastreador is not None:
            if self.processo_rastreador.poll() is None:
                self.status_var.set("Rastreador já está ativo")
                return
            self.fechar_logs()
            self.processo_rastreador = None

        porta = self.obter_porta_rastreador()
        if porta is None:
            self.reiniciar_automaticamente = False
            self.status_var.set("Rastreador parado — Arduino/Pro Micro não encontrado")
            if not automatico:
                messagebox.showwarning(
                    "Porta serial indisponível",
                    self.mensagem_porta_indisponivel(),
                    parent=self.root,
                )
            return

        try:
            dados = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if dados.get("porta") != porta:
                dados["porta"] = porta
                temporario = CONFIG_PATH.with_suffix(".tmp")
                temporario.write_text(
                    json.dumps(dados, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8",
                )
                os.replace(temporario, CONFIG_PATH)
        except (OSError, json.JSONDecodeError):
            self.status_var.set("Falha ao salvar a porta serial detectada")
            return

        self.encerrar_rastreadores_antigos()

        try:
            LOGS_DIR.mkdir(exist_ok=True)
            self.arquivo_log_saida = open(
                LOGS_DIR / "rastreador_painel.out.log",
                "a",
                encoding="utf-8",
                buffering=1,
            )
            self.arquivo_log_erro = open(
                LOGS_DIR / "rastreador_painel.err.log",
                "a",
                encoding="utf-8",
                buffering=1,
            )
            self.arquivo_log_saida.write("\n--- nova inicialização ---\n")
            kwargs = {
                "cwd": str(BASE_DIR),
                "stdout": self.arquivo_log_saida,
                "stderr": self.arquivo_log_erro,
            }
            if os.name == "nt":
                kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
            comando_rastreador = (
                [sys.executable, "--tracker"]
                if getattr(sys, "frozen", False)
                else [sys.executable, str(TRACKER_PATH), "--tracker"]
            )
            self.processo_rastreador = subprocess.Popen(
                comando_rastreador, **kwargs
            )
            self.inicio_rastreador = time.monotonic()
            self.status_var.set(
                f"Rastreador iniciado — PID {self.processo_rastreador.pid}"
            )
        except OSError as erro:
            self.fechar_logs()
            messagebox.showerror("Falha ao iniciar", str(erro))

    def fechar_logs(self):
        for nome in ("arquivo_log_saida", "arquivo_log_erro"):
            arquivo = getattr(self, nome, None)
            if arquivo is not None:
                try:
                    arquivo.flush()
                    arquivo.close()
                except OSError:
                    pass
                setattr(self, nome, None)

    def parar(self):
        processo = self.processo_rastreador
        if processo is None or processo.poll() is not None:
            self.fechar_logs()
            self.status_var.set("Rastreador parado")
            return
        processo.terminate()
        try:
            processo.wait(timeout=2)
        except subprocess.TimeoutExpired:
            processo.kill()
        self.fechar_logs()
        self.reiniciar_automaticamente = False
        self.status_var.set("Rastreador parado")
        self.processo_rastreador = None

    def atualizar_status(self):
        if self.processo_rastreador is not None:
            if self.processo_rastreador.poll() is None:
                if (
                    self.inicio_rastreador is not None
                    and time.monotonic() - self.inicio_rastreador > 5
                ):
                    self.tentativas_reinicio = 0
                self.status_var.set(
                    f"Rastreador ativo — PID {self.processo_rastreador.pid}"
                )
            else:
                self.fechar_logs()
                self.processo_rastreador = None
                iniciou_recentemente = (
                    self.inicio_rastreador is not None
                    and time.monotonic() - self.inicio_rastreador < 5
                )
                if (
                    self.reiniciar_automaticamente
                    and self.tentativas_reinicio < 3
                    and not iniciou_recentemente
                ):
                    self.tentativas_reinicio += 1
                    tentativa = self.tentativas_reinicio
                    self.status_var.set(
                        f"Rastreador encerrou; reiniciando ({tentativa}/3)..."
                    )
                    self.root.after(
                        500, lambda: self.iniciar(automatico=True)
                    )
                else:
                    if iniciou_recentemente:
                        self.reiniciar_automaticamente = False
                    self.status_var.set(
                        "Rastreador encerrou ao iniciar; confira a placa e a porta serial"
                        if iniciou_recentemente
                        else "Rastreador encerrado; veja logs/rastreador_painel.err.log"
                    )
        self.root.after(700, self.atualizar_status)

    def fechar(self):
        self.reiniciar_automaticamente = False
        if self.autoaplicar_job is not None:
            try:
                self.root.after_cancel(self.autoaplicar_job)
            except tk.TclError:
                pass
            self.autoaplicar_job = None
        self.parar()
        self.root.destroy()


def painel_main():
    root = tk.Tk()
    painel = PainelRastreador(root)
    root.after(300, painel.iniciar)
    root.mainloop()




