import atexit
import ctypes
import json
import math
import sys
import threading
import time
from ctypes import wintypes
from pathlib import Path

import cv2
import mss
import numpy as np
import serial
from .perfis_sonoros import normalizar_perfil_sonoro, tons_do_perfil

try:
    import dxcam
except ImportError:
    dxcam = None

try:
    import simpleaudio as simpleaudio_backend
except ImportError:
    simpleaudio_backend = None


def obter_base_dir(executavel=None, congelado=None):
    """Retorna a raiz que contém a configuração compartilhada do rastreador."""
    if congelado is None:
        congelado = getattr(sys, "frozen", False)
    if congelado:
        diretorio_executavel = Path(executavel or sys.executable).resolve().parent
        raiz_compartilhada = diretorio_executavel.parent
        # No pacote Windows, o binário do rastreador fica em ``tracker/`` e o
        # agente sincroniza config/pause na raiz do produto. Usar a mesma raiz
        # impede o fallback silencioso para o perfil som_01 do binário isolado.
        if diretorio_executavel.name.lower() == "tracker" and (raiz_compartilhada / "config_rastreador.json").exists():
            return raiz_compartilhada
        return diretorio_executavel
    # Este arquivo fica em ``modulos``; os recursos continuam na raiz do projeto.
    return Path(__file__).resolve().parent.parent


BASE_DIR = obter_base_dir()
CONFIG_PATH = BASE_DIR / "config_rastreador.json"
PAUSA_PATH = BASE_DIR / "estado_pausa_rastreador.json"
SOUND_DIR = BASE_DIR / "sounds"

CONFIG_PADRAO = {
    "porta": "COM11",
    "modo_ativacao": "mirando",
    "modo_deteccao": "preenchido",
    "hotkey_pausa": "f8",
    "baudrate": 115200,
    "cor_hex": "#800000",
    "tolerancia_rgb": 20,
    # Perfil consolidado de resposta, inspirado na associação temporal do Prime Aim.
    "ganho": 0.35,
    # Altura Prime-like do ponto de aterrissagem, em pixels locais do FOV.
    "altura_puxada": 0,
    # Offset Prime-like do ponto de aterrissagem, em pixels locais do FOV.
    "offset_vertical_px": 0,
    "passo_maximo": 24,
    "zona_morta": 3,
    "filtro_alvo": 0.90,
    "distancia_reaquisicao": 140,
    "fov_diametro": 600,
    # Diâmetro do círculo central ignorado dentro do FOV; 0 desativa.
    "zona_exclusao_diametro": 0,
    "taxa_alvo_hz": 165.0,
    "area_minima": 2,
    "confirmacoes_alvo": 1,
    "atraso_aquisicao_ms": 20,
    "rampa_movimento_ms": 45,
    "microtremor_px": 0.15,
    "humanizacao_forca": 0.36,
    "humanizacao_suavizacao": 0.075,
    "humanizacao_duracao": 18,
    "perfil_movimento": "natural",
    # Nenhum tom é tocado até o painel sincronizar explicitamente um perfil.
    "perfil_som": None,
    "teste_tracado_id": 0,
    "prioridade_centro": 0.85,
    "ignorar_barras": True,
    "ignorar_triangulos_invertidos": True,
    "modo_adaptativo": True,
    "detectar_longa_distancia": True,
}

VK_BOTAO_MIRAR = 0x02
VK_BOTAO_ATIRAR = 0x01
VK_MOUSE_LATERAL_1 = 0x05
VK_MOUSE_LATERAL_2 = 0x06
VK_HOTKEYS = {
    "f6": 0x75,
    "f7": 0x76,
    "f8": 0x77,
    "f9": 0x78,
    "f10": 0x79,
    "mouse4": VK_MOUSE_LATERAL_1,
    "mouse5": VK_MOUSE_LATERAL_2,
}
JANELA_ATUALIZACAO_SEGUNDOS = 0.50
CONFIG_ATUALIZACAO_SEGUNDOS = 0.50
CONFIRMACOES_MINIMAS = 2
DISTANCIA_CONFIRMACAO = 10.0
MARGEM_ESPERA_PRECISA = 0.0015
MASCARA_CIRCULAR_CACHE = {}
MASCARA_EXCLUSAO_CACHE = {}
KERNEL_MORFOLOGIA = np.ones((3, 3), np.uint8)
KERNEL_MORFOLOGIA_PEQUENA = np.ones((2, 2), np.uint8)


class FalhaComunicacaoSerial(RuntimeError):
    """Sinaliza perda da placa ou falha de escrita sem mascarar a causa."""


def enviar_serial(placa, comando):
    """Envia uma linha ASCII e converte falhas da porta em erro do rastreador."""
    dados = comando.encode("ascii") if isinstance(comando, str) else comando
    try:
        placa.write(dados)
    except (serial.SerialException, OSError) as erro:
        raise FalhaComunicacaoSerial(
            f"falha ao enviar {dados!r}: {erro}"
        ) from erro


user32 = ctypes.windll.user32
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetWindowRect.argtypes = [
    wintypes.HWND,
    ctypes.POINTER(wintypes.RECT),
]
user32.GetWindowRect.restype = wintypes.BOOL
user32.GetClientRect.argtypes = [
    wintypes.HWND,
    ctypes.POINTER(wintypes.RECT),
]
user32.GetClientRect.restype = wintypes.BOOL
user32.ClientToScreen.argtypes = [
    wintypes.HWND,
    ctypes.POINTER(wintypes.POINT),
]
user32.ClientToScreen.restype = wintypes.BOOL
try:
    user32.SetProcessDPIAware()
except AttributeError:
    pass


def limitar(valor, minimo, maximo):
    return max(minimo, min(maximo, valor))


def microvariacao_suave(tempo, amplitude):
    """Gera uma variação pequena, contínua e limitada, sem saltos aleatórios."""
    if amplitude <= 0.0:
        return 0.0, 0.0
    # Frequências baixas e não sincronizadas simulam pequenas oscilações da mão
    # sem transformar o ruído em uma troca brusca de direção.
    eixo_x = (
        math.sin(tempo * 2.0 * math.pi * 1.35)
        + 0.45 * math.sin(tempo * 2.0 * math.pi * 2.15 + 1.7)
    ) / 1.45
    eixo_y = (
        math.cos(tempo * 2.0 * math.pi * 1.10 + 0.8)
        + 0.40 * math.sin(tempo * 2.0 * math.pi * 1.90 + 2.4)
    ) / 1.40
    return amplitude * eixo_x, amplitude * eixo_y


def configurar_humanizacao_placa(placa, config):
    """Envia ao Pro Micro os controles de curva escolhidos no painel."""
    forca = int(round(float(config["humanizacao_forca"]) * 1000.0))
    suavizacao = int(round(float(config["humanizacao_suavizacao"]) * 1000.0))
    duracao = int(config["humanizacao_duracao"])
    enviar_serial(placa, f"HUMANIZE {forca} {suavizacao} {duracao}\n")


def executar_teste_tracado(placa):
    """Desenha uma curva curta para calibração no aplicativo em primeiro plano."""
    print("Teste de traçado: iniciando em 2 segundos.", flush=True)
    time.sleep(2.0)
    # Curva em S: pontos espaçados mantêm o desenho contínuo e deixam o
    # firmware aplicar a humanização atualmente selecionada.
    pontos = []
    for indice in range(1, 37):
        t = indice / 36.0
        pontos.append((int(round(280.0 * t)), int(round(42.0 * math.sin(t * math.pi * 2.0)))))
    enviar_serial(placa, "PRESS LEFT\n")
    anterior_x = 0
    anterior_y = 0
    for x, y in pontos:
        enviar_serial(placa, f"MOVE {x - anterior_x} {y - anterior_y}\n")
        anterior_x, anterior_y = x, y
        time.sleep(0.018)
    time.sleep(0.35)
    enviar_serial(placa, "RELEASE LEFT\n")
    print("Teste de traçado concluído.", flush=True)


def parametros_adaptativos(config, alvo, erro_x, erro_y):
    """Ajusta parâmetros dentro de limites conforme tamanho e distância do alvo."""
    if not config.get("modo_adaptativo", False) or alvo is None:
        return {
            "ganho": float(config["ganho"]),
            "filtro": float(config["filtro_alvo"]),
            "passo_maximo": int(config["passo_maximo"]),
            "atraso_ms": int(config["atraso_aquisicao_ms"]),
            "rampa_ms": int(config["rampa_movimento_ms"]),
            "microtremor_px": float(config["microtremor_px"]),
        }

    area = max(1.0, float(alvo[2]))
    tamanho = limitar(math.sqrt(area) / 18.0, 0.0, 1.0)
    distancia = limitar(math.hypot(float(erro_x), float(erro_y)) / 260.0, 0.0, 1.0)
    filtro_auto = 0.42 + 0.48 * tamanho
    filtro = limitar(min(float(config["filtro_alvo"]), filtro_auto), 0.32, 1.0)
    # Não impor um piso alto: o valor do painel precisa continuar sendo efetivo.
    # Antes, 0,01 era elevado internamente para aproximadamente 0,18, tornando
    # o controle praticamente inútil para reduzir a agressividade.
    ganho_base = max(0.01, float(config["ganho"]))
    ganho = limitar(
        ganho_base * (0.90 + 0.22 * tamanho) * (0.92 + 0.20 * distancia),
        0.005,
        0.85,
    )
    passo_base = max(6, int(config["passo_maximo"]))
    passo_maximo = int(
        limitar(round(passo_base * (0.86 + 0.34 * distancia)), 6, 32)
    )
    # Alvos pequenos costumam estar distantes; não os deixe esperando
    # uma rampa longa que termina antes de haver deslocamento útil.
    atraso_ms = int(limitar(8.0 + tamanho * 14.0, 8, 24))
    rampa_ms = int(limitar(16.0 + tamanho * 20.0, 16, 38))
    microtremor = limitar(float(config["microtremor_px"]), 0.0, 0.35)
    return {
        "ganho": ganho,
        "filtro": filtro,
        "passo_maximo": passo_maximo,
        "atraso_ms": atraso_ms,
        "rampa_ms": rampa_ms,
        "microtremor_px": microtremor,
    }


def area_minima_efetiva(config):
    """Calcula o menor componente aceitável sem liberar ruído de um pixel."""
    try:
        valor = int(round(float(config.get("area_minima", 2))))
    except (TypeError, ValueError):
        valor = 2
    valor = max(2, valor)
    if config.get("modo_adaptativo", False):
        # Recupera um pixel perdido por antialiasing, mas nunca aceita
        # componente unitário isolado como alvo.
        valor = max(2, valor - 1)
    return valor


def curva_ganho_prime(distance, referencia):
    """Curva de distância do Prime Aim para o ganho de aproximação."""
    referencia = max(1.0, float(referencia))
    distancia = max(0.0, float(distance))
    limite_proximo = referencia * 0.30
    limite_medio = referencia * 0.60
    if distancia < limite_proximo:
        return 1.15
    if distancia >= limite_medio:
        return 0.75
    meio = (limite_proximo + limite_medio) * 0.5
    if distancia < meio:
        progresso = limitar(
            (distancia - limite_proximo) / max(1.0, meio - limite_proximo),
            0.0,
            1.0,
        )
        suave = progresso * progresso * (3.0 - 2.0 * progresso)
        return 1.15 - 0.15 * suave
    progresso = limitar(
        (distancia - meio) / max(1.0, limite_medio - meio),
        0.0,
        1.0,
    )
    suave = progresso * progresso * (3.0 - 2.0 * progresso)
    return 1.00 - 0.25 * suave


def ganho_aterrissagem_prime(distance, estabilidade):
    """Reduz microcorreções finais com estabilidade/histerese suave."""
    estabilidade = limitar(float(estabilidade), 0.0, 10.0) / 10.0
    normalizada = limitar(float(distance) / 80.0, 0.0, 1.0)
    minimo = 0.58 + (1.0 - estabilidade) * 0.08
    return minimo + (1.0 - minimo) * normalizada


def sinal_mudou(valor, anterior):
    return (
        anterior is not None
        and valor != 0.0
        and anterior != 0.0
        and ((valor < 0.0 < anterior) or (valor > 0.0 > anterior))
    )


def hex_para_rgb(cor_hex):
    texto = str(cor_hex).strip().lstrip("#")
    if len(texto) != 6:
        raise ValueError("A cor precisa ter seis dígitos hexadecimais.")
    try:
        vermelho = int(texto[0:2], 16)
        verde = int(texto[2:4], 16)
        azul = int(texto[4:6], 16)
    except ValueError as erro:
        raise ValueError("A cor hexadecimal é inválida.") from erro
    return vermelho, verde, azul


def normalizar_configuracao(dados):
    config = CONFIG_PADRAO.copy()
    if isinstance(dados, dict):
        config.update(dados)

    # Campo vazio/inválido significa "sem alvo"; nunca substitua por uma cor
    # padrão, pois isso faria o rastreador puxar sem cor configurada.
    cor_informada = isinstance(dados, dict) and "cor_hex" in dados
    try:
        vermelho, verde, azul = hex_para_rgb(config["cor_hex"])
        config["cor_hex"] = f"#{vermelho:02X}{verde:02X}{azul:02X}"
    except (KeyError, TypeError, ValueError):
        if cor_informada:
            vermelho, verde, azul = (0, 0, 0)
            config["cor_hex"] = ""
        else:
            vermelho, verde, azul = hex_para_rgb(CONFIG_PADRAO["cor_hex"])
            config["cor_hex"] = CONFIG_PADRAO["cor_hex"]

    # A lista de cores salvas é apenas um atalho de interface. O rastreador
    # trabalha com uma única cor ativa e não pode reintroduzir cores antigas
    # quando o arquivo local ainda contém valores de versões anteriores.
    config["cores_salvas"] = [config["cor_hex"]] if config["cor_hex"] else []

    def numero(nome, minimo, maximo, inteiro=False):
        try:
            valor = float(config[nome])
        except (KeyError, TypeError, ValueError):
            valor = float(CONFIG_PADRAO[nome])
        valor = limitar(valor, minimo, maximo)
        return int(round(valor)) if inteiro else valor

    config["tolerancia_rgb"] = numero("tolerancia_rgb", 0, 100, True)
    config["ganho"] = numero("ganho", 0.01, 2.0)
    config["altura_puxada"] = numero("altura_puxada", -400, 400, True)
    # Prime Aim usa o offset vertical para mover o ponto de aterrissagem do
    # centro. Mantemos faixa ampla, mas limitada para evitar comandos extremos.
    config["offset_vertical_px"] = numero("offset_vertical_px", -200, 200, True)
    config["passo_maximo"] = numero("passo_maximo", 1, 100, True)
    config["zona_morta"] = numero("zona_morta", 0, 50, True)
    config["filtro_alvo"] = numero("filtro_alvo", 0.01, 1.0)
    config["distancia_reaquisicao"] = numero(
        "distancia_reaquisicao", 20, 500, True
    )
    config["fov_diametro"] = numero("fov_diametro", 100, 1600, True)
    config["zona_exclusao_diametro"] = numero(
        "zona_exclusao_diametro", 0, 600, True
    )
    config["taxa_alvo_hz"] = numero("taxa_alvo_hz", 30, 300)
    modos_validos = {"mirando", "atirando", "ambos", "mirando_atirando"}
    modo_ativacao = str(config.get("modo_ativacao", "mirando")).strip().lower()
    config["modo_ativacao"] = (
        modo_ativacao if modo_ativacao in modos_validos else "mirando"
    )
    modos_deteccao_validos = {"preenchido", "contorno"}
    modo_deteccao = str(
        config.get("modo_deteccao", "preenchido")
    ).strip().lower()
    config["modo_deteccao"] = (
        modo_deteccao if modo_deteccao in modos_deteccao_validos else "preenchido"
    )
    hotkey_pausa = str(config.get("hotkey_pausa", "f8")).strip().lower()
    hotkeys_validas = set(VK_HOTKEYS) | {"none"}
    config["hotkey_pausa"] = (
        hotkey_pausa if hotkey_pausa in hotkeys_validas else "f8"
    )
    # Um único pixel ou ruído de compressão nunca pode virar alvo.
    # Alvos distantes podem ocupar poucos pixels; o filtro geométrico continua removendo formatos indesejados.
    config["area_minima"] = numero("area_minima", 1, 5000, True)
    config["confirmacoes_alvo"] = numero("confirmacoes_alvo", 1, 8, True)
    config["atraso_aquisicao_ms"] = numero("atraso_aquisicao_ms", 0, 250, True)
    config["rampa_movimento_ms"] = numero("rampa_movimento_ms", 0, 300, True)
    config["microtremor_px"] = numero("microtremor_px", 0.0, 2.0)
    config["humanizacao_forca"] = numero("humanizacao_forca", 0.0, 1.0)
    config["humanizacao_suavizacao"] = numero("humanizacao_suavizacao", 0.01, 0.5)
    config["humanizacao_duracao"] = numero("humanizacao_duracao", 1, 80, True)
    perfis_humanizacao = {
        "reto_suave": (0.0, 0.075, 18, 0.0),
        "natural": (0.36, 0.075, 18, 0.15),
        "mao_tremula": (0.58, 0.12, 10, 0.55),
        "curvas_fortes": (0.82, 0.055, 30, 0.22),
    }
    perfil = str(config.get("perfil_movimento", "personalizado")).strip().lower()
    if perfil in perfis_humanizacao:
        config["perfil_movimento"] = perfil
        for nome, valor in zip(
            ("humanizacao_forca", "humanizacao_suavizacao", "humanizacao_duracao", "microtremor_px"),
            perfis_humanizacao[perfil],
        ):
            config[nome] = valor
    else:
        config["perfil_movimento"] = "personalizado"
    config["perfil_som"] = normalizar_perfil_sonoro(config.get("perfil_som"))
    config["teste_tracado_id"] = numero("teste_tracado_id", 0, 2_000_000_000, True)
    config["prioridade_centro"] = numero("prioridade_centro", 0.0, 1.0)
    config["ignorar_barras"] = bool(config.get("ignorar_barras", True))
    config["ignorar_triangulos_invertidos"] = bool(
        config.get("ignorar_triangulos_invertidos", True)
    )
    config["modo_adaptativo"] = bool(config.get("modo_adaptativo", True))
    config["detectar_longa_distancia"] = bool(
        config.get("detectar_longa_distancia", True)
    )
    config["porta"] = str(config.get("porta", CONFIG_PADRAO["porta"]))
    config["baudrate"] = int(config.get("baudrate", CONFIG_PADRAO["baudrate"]))
    config["cor_rgb"] = (vermelho, verde, azul)
    return config


def carregar_configuracao():
    try:
        dados = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        dados = {}
    return normalizar_configuracao(dados)


def botoes_esta_pressionados():
    """Retorna (mirando, atirando) usando os botões direito e esquerdo."""
    mirando = bool(user32.GetAsyncKeyState(VK_BOTAO_MIRAR) & 0x8000)
    atirando = bool(user32.GetAsyncKeyState(VK_BOTAO_ATIRAR) & 0x8000)
    return mirando, atirando


def ler_estado_pausa():
    try:
        dados = json.loads(PAUSA_PATH.read_text(encoding="utf-8"))
        return bool(dados.get("pausado", False))
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return False


def gravar_estado_pausa(pausado):
    temporario = PAUSA_PATH.with_suffix(".tmp")
    temporario.write_text(
        json.dumps({"pausado": bool(pausado)}) + "\n",
        encoding="utf-8",
    )
    temporario.replace(PAUSA_PATH)


def hotkey_esta_pressionada(nome):
    nome_normalizado = str(nome or "").strip().lower()
    codigo = VK_HOTKEYS.get(nome_normalizado)
    if codigo is None:
        return False
    try:
        return bool(user32.GetAsyncKeyState(codigo) & 0x8000)
    except (AttributeError, OSError):
        # Sem acesso temporário à API do Windows, a escolha segura é não
        # alternar o estado. O laço continuará permitindo nova tentativa.
        return False


def perfil_som_mais_recente(config):
    """Lê o perfil sincronizado; configuração ausente significa silêncio seguro."""
    try:
        dados_do_disco = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        perfil_do_painel = normalizar_perfil_sonoro(dados_do_disco.get("perfil_som"))
        if perfil_do_painel is not None:
            return perfil_do_painel
    except (OSError, json.JSONDecodeError, TypeError):
        pass
    return normalizar_perfil_sonoro(config.get("perfil_som"))


def emitir_som_estado(pausado, perfil_som=None):
    """Reproduz somente o WAV versionado do perfil selecionado."""
    perfil = normalizar_perfil_sonoro(perfil_som)
    if simpleaudio_backend is None or perfil is None:
        return
    estado = "deactivation" if pausado else "activation"
    caminho = SOUND_DIR / f"{perfil}-{estado}.wav"
    if not caminho.is_file():
        return

    def tocar():
        try:
            reproducao = simpleaudio_backend.WaveObject.from_wave_file(str(caminho)).play()
            reproducao.wait_done()
        except (OSError, RuntimeError, ValueError):
            # Falha de áudio deve ser silenciosa; não existe fallback para o
            # sinal do sistema operacional.
            pass

    threading.Thread(target=tocar, daemon=True).start()


def modo_ativacao_esta_ativo(modo, mirando, atirando):
    """Aplica a condição selecionada no painel para ativar o rastreamento."""
    if modo == "atirando":
        return atirando
    if modo == "ambos":
        return mirando or atirando
    if modo == "mirando_atirando":
        return mirando and atirando
    return mirando


def posicao_cursor():
    ponto = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(ponto))
    return ponto.x, ponto.y


def obter_janela_ativa():
    """Retorna o retângulo da janela ativa ou None se não for válido."""
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return None

    retangulo = wintypes.RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(retangulo)):
        return None

    origem = wintypes.POINT(0, 0)
    if not user32.ClientToScreen(hwnd, ctypes.byref(origem)):
        return None

    largura = retangulo.right - retangulo.left
    altura = retangulo.bottom - retangulo.top
    if largura < 100 or altura < 100:
        return None

    return {
        "hwnd": hwnd,
        "left": origem.x,
        "top": origem.y,
        "width": largura,
        "height": altura,
    }


def calcular_fov_janela(janela, diametro_solicitado):
    limite = min(janela["width"], janela["height"])
    diametro = int(limitar(diametro_solicitado, 100, limite))
    left = janela["left"] + (janela["width"] - diametro) // 2
    top = janela["top"] + (janela["height"] - diametro) // 2
    regiao = {
        "left": left,
        "top": top,
        "width": diametro,
        "height": diametro,
    }
    return diametro, left, top, regiao


def atualizar_monitores_mss(captura):
    """Atualiza a lista de monitores após troca de resolução ou modo de tela."""
    try:
        with mss.MSS() as nova_captura:
            monitores = [dict(item) for item in nova_captura.monitors]
        captura._monitors = monitores
    except Exception:
        pass
    return captura.monitors[1:]


def monitor_por_ponto(monitores, x, y):
    for indice, monitor in enumerate(monitores, start=1):
        if (
            monitor["left"] <= x < monitor["left"] + monitor["width"]
            and monitor["top"] <= y < monitor["top"] + monitor["height"]
        ):
            return indice, monitor
    for indice, monitor in enumerate(monitores, start=1):
        if monitor.get("is_primary"):
            return indice, monitor
    return (1, monitores[0]) if monitores else (None, None)


def monitor_selecionado(captura, config):
    """Retorna a área de captura, o monitor MSS e o output DXGI correspondente."""
    monitores = atualizar_monitores_mss(captura)
    if not monitores:
        return None

    selecao = config.get("monitor_selecionado", "principal")
    indice = None
    monitor = None
    janela = None

    if selecao == "janela_ativa":
        janela = obter_janela_ativa()
        if janela is not None:
            centro_x = janela["left"] + janela["width"] // 2
            centro_y = janela["top"] + janela["height"] // 2
            indice, monitor = monitor_por_ponto(monitores, centro_x, centro_y)
        if janela is None:
            selecao = "principal"

    if janela is None:
        if selecao == "principal":
            for candidato, item in enumerate(monitores, start=1):
                if item.get("is_primary"):
                    indice, monitor = candidato, item
                    break
            if monitor is None:
                indice, monitor = 1, monitores[0]
        else:
            try:
                candidato = int(selecao)
            except (TypeError, ValueError):
                candidato = 1
            if 1 <= candidato <= len(monitores):
                indice, monitor = candidato, monitores[candidato - 1]
            else:
                indice, monitor = monitor_por_ponto(monitores, 0, 0)

    if janela is None:
        janela = {
            "hwnd": None,
            "left": int(monitor["left"]),
            "top": int(monitor["top"]),
            "width": int(monitor["width"]),
            "height": int(monitor["height"]),
        }

    janela["mss_index"] = int(indice)
    janela["monitor_left"] = int(monitor["left"])
    janela["monitor_top"] = int(monitor["top"])
    janela["monitor_width"] = int(monitor["width"])
    janela["monitor_height"] = int(monitor["height"])
    janela["dxgi_output_idx"] = max(0, int(indice) - 1)
    janela["monitor_selecao"] = selecao
    return janela


def regiao_dxgi_local(regiao_fov, area):
    """Converte coordenadas do desktop virtual para o output DXGI selecionado."""
    origem_x = area.get("monitor_left", 0)
    origem_y = area.get("monitor_top", 0)
    return (
        int(regiao_fov["left"] - origem_x),
        int(regiao_fov["top"] - origem_y),
        int(regiao_fov["left"] + regiao_fov["width"] - origem_x),
        int(regiao_fov["top"] + regiao_fov["height"] - origem_y),
    )


def iniciar_camera_dxgi(area, regiao_fov):
    if dxcam is None:
        return None
    camera = None
    try:
        camera = dxcam.create(
            device_idx=0,
            output_idx=area.get("dxgi_output_idx", 0),
            output_color="BGR",
        )
        camera.start(
            region=regiao_dxgi_local(regiao_fov, area),
            target_fps=240,
            video_mode=True,
        )
        print(
            f"Captura DXGI ativada no output {area.get('dxgi_output_idx', 0)}.",
            flush=True,
        )
        return camera
    except Exception as erro:
        if camera is not None:
            try:
                camera.stop()
            except Exception:
                pass
        print(f"DXGI indisponível neste momento: {erro}; usando MSS.", flush=True)
        return None


def liberar_camera_dxgi(camera, output_idx=None):
    if camera is None:
        return
    try:
        camera.stop()
    except Exception:
        pass
    try:
        camera.release()
    except Exception:
        pass

    # O DXCam mantém câmeras por output num WeakValueDictionary. O objeto
    # ainda pode estar referenciado pelo loop, portanto removemos a entrada
    # explicitamente antes de criar outra câmera para o mesmo output.
    try:
        fabrica = getattr(dxcam, "__factory", None)
        cache = getattr(fabrica, "_camera_instances", None)
        if cache is not None and output_idx is not None:
            cache.pop((0, int(output_idx), "dxgi"), None)
    except Exception:
        pass


def reiniciar_camera_dxgi(camera, area, regiao_fov):
    output_idx = area.get("dxgi_output_idx", 0)
    liberar_camera_dxgi(camera, output_idx)
    return iniciar_camera_dxgi(area, regiao_fov)


def obter_mascara_circular(largura, altura):
    chave = (int(largura), int(altura))
    mascara = MASCARA_CIRCULAR_CACHE.get(chave)
    if mascara is None:
        centro_x = largura // 2
        centro_y = altura // 2
        raio = min(largura, altura) // 2
        eixo_y, eixo_x = np.ogrid[:altura, :largura]
        mascara = (
            (eixo_x - centro_x) ** 2 + (eixo_y - centro_y) ** 2 <= raio**2
        ).astype(np.uint8) * 255
        MASCARA_CIRCULAR_CACHE[chave] = mascara
    return mascara


def obter_mascara_exclusao_central(largura, altura, diametro):
    """Cria um círculo central que será removido do FOV de detecção."""
    diametro = max(0, int(diametro))
    if diametro <= 0:
        return None
    chave = (int(largura), int(altura), diametro)
    mascara = MASCARA_EXCLUSAO_CACHE.get(chave)
    if mascara is None:
        centro_x = (largura - 1) / 2.0
        centro_y = (altura - 1) / 2.0
        raio = diametro / 2.0
        eixo_y, eixo_x = np.ogrid[:altura, :largura]
        mascara = (
            (eixo_x - centro_x) ** 2 + (eixo_y - centro_y) ** 2 <= raio**2
        ).astype(np.uint8) * 255
        MASCARA_EXCLUSAO_CACHE[chave] = mascara
    return mascara


def mascara_cor_longa_distancia(imagem_bgr, cor_rgb, tolerancia_rgb):
    """Reconhece a cromaticidade da cor quando a distância reduz o brilho.

    A regra RGB estrita continua ativa. Esta máscara adicional não abre os
    três canais: compara matiz circular, saturação e dominância da cor. Isso
    recupera vermelhos escuros/antialiasados sem aceitar cinza, marrom lavado
    ou cores de outra família apenas porque o RGB ficou mais tolerante.
    """
    vermelho, verde, azul = cor_rgb
    amostra = np.array([[[azul, verde, vermelho]]], dtype=np.uint8)
    hsv_alvo = cv2.cvtColor(amostra, cv2.COLOR_BGR2HSV)[0, 0]
    if int(hsv_alvo[1]) < 80:
        # Para cores quase sem saturação, matiz não é uma informação segura.
        return np.zeros(imagem_bgr.shape[:2], dtype=np.uint8)

    hsv = cv2.cvtColor(imagem_bgr, cv2.COLOR_BGR2HSV)
    diferenca_matiz = np.abs(hsv[:, :, 0].astype(np.int16) - int(hsv_alvo[0]))
    diferenca_matiz = np.minimum(diferenca_matiz, 180 - diferenca_matiz)
    tolerancia_matiz = int(limitar(4 + int(tolerancia_rgb) * 0.08, 5, 12))
    saturacao_minima = int(max(90, int(hsv_alvo[1]) - int(tolerancia_rgb) * 2))
    valor_minimo = int(max(20, int(hsv_alvo[2]) - int(tolerancia_rgb) * 3))
    indice_principal = int(np.argmax(np.array([azul, verde, vermelho])))
    canal_principal = imagem_bgr[:, :, indice_principal].astype(np.int16)
    outros_canais = [indice for indice in range(3) if indice != indice_principal]
    maior_secundario = np.maximum(
        imagem_bgr[:, :, outros_canais[0]].astype(np.int16),
        imagem_bgr[:, :, outros_canais[1]].astype(np.int16),
    )
    # Mantém a assinatura cromática: para vermelho puro, por exemplo, R deve
    # continuar ao menos três vezes acima do maior canal secundário.
    dominante = canal_principal >= maior_secundario * 3 + 8
    aceita = (
        (diferenca_matiz <= tolerancia_matiz)
        & (hsv[:, :, 1] >= saturacao_minima)
        & (hsv[:, :, 2] >= valor_minimo)
        & dominante
    )
    return aceita.astype(np.uint8) * 255


def formato_triangular_invertido(contorno, largura, altura):
    """Identifica um contorno aproximadamente triangular com vértice para baixo."""
    if contorno is None or largura < 4 or altura < 4:
        return False
    perimetro = cv2.arcLength(contorno, True)
    if perimetro <= 0.0:
        return False
    aproximado = cv2.approxPolyDP(contorno, 0.045 * perimetro, True)
    if len(aproximado) != 3:
        return False
    pontos = aproximado.reshape(-1, 2).astype(np.float32)
    indice_apice = int(np.argmax(pontos[:, 1]))
    apice_y = float(pontos[indice_apice, 1])
    base_y = float(np.mean(np.delete(pontos[:, 1], indice_apice)))
    return (
        apice_y - base_y >= max(2.0, float(altura) * 0.22)
        and float(np.max(pontos[:, 1]) - np.min(pontos[:, 1]))
        >= float(altura) * 0.35
    )


def formato_deve_ser_ignorado(contorno, mascara_regiao, largura, altura, config):
    """Rejeita geometrias que aparecem nos exemplos, antes da seleção do alvo."""
    if config.get("ignorar_barras", True):
        proporcao = float(largura) / max(1.0, float(altura))
        # A barra problemática é larga e baixa; não bloqueamos retângulos
        # compactos para não eliminar alvos pequenos e preenchidos.
        if proporcao >= 4.5 and altura <= 18:
            return True
    if config.get("ignorar_triangulos_invertidos", True):
        contorno_analise = contorno
        if contorno_analise is None and mascara_regiao is not None:
            contornos_regiao, _ = cv2.findContours(
                mascara_regiao, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            if contornos_regiao:
                contorno_analise = max(contornos_regiao, key=cv2.contourArea)
        if formato_triangular_invertido(contorno_analise, largura, altura):
            return True
    return False


def detectar_alvo_fov_circular(imagem_bgra, config, referencia=None):
    """Retorna o alvo mais próximo da referência ou o maior alvo inicial."""
    cor_hex = str(config.get("cor_hex", "")).strip()
    if len(cor_hex) != 7 or not cor_hex.startswith("#"):
        return None
    # mss entrega BGRA; os três primeiros canais já estão em BGR.
    imagem_bgr = imagem_bgra[:, :, :3]
    altura, largura = imagem_bgr.shape[:2]
    mascara_circular = obter_mascara_circular(largura, altura)

    vermelho, verde, azul = config["cor_rgb"]
    cor_alvo_bgr = np.array([azul, verde, vermelho], dtype=np.int16)
    tolerancia_base = int(config["tolerancia_rgb"])
    # O valor do painel é aplicado literalmente, por canal, sem margem oculta.
    # Assim, tolerância ±22 significa exatamente ±22 em R, G e B.
    tolerancia_efetiva = tolerancia_base
    cor_minima = np.maximum(
        cor_alvo_bgr - tolerancia_efetiva, 0
    ).astype(np.uint8)
    cor_maxima = np.minimum(
        cor_alvo_bgr + tolerancia_efetiva, 255
    ).astype(np.uint8)
    mascara_cor = cv2.inRange(imagem_bgr, cor_minima, cor_maxima)
    if config.get("detectar_longa_distancia", True):
        mascara_distante = mascara_cor_longa_distancia(
            imagem_bgr, config["cor_rgb"], tolerancia_base
        )
        mascara_cor = cv2.bitwise_or(mascara_cor, mascara_distante)

    # O FOV efetivo é o círculo externo menos a zona circular central opcional.
    # Isso evita que a bolinha da mira seja considerada um alvo.
    mascara_fov = mascara_circular
    mascara_exclusao = obter_mascara_exclusao_central(
        largura, altura, config.get("zona_exclusao_diametro", 0)
    )
    if mascara_exclusao is not None:
        mascara_fov = cv2.bitwise_and(
            mascara_circular, cv2.bitwise_not(mascara_exclusao)
        )

    # A área mínima já remove ruído pequeno. O modo contorno usa uma operação
    # morfológica somente quando solicitado; o caminho preenchido permanece
    # sem morfologia para preservar a cadência de alta frequência.
    mascara = cv2.bitwise_and(mascara_cor, mascara_fov)
    candidatos = []
    limiar_area = area_minima_efetiva(config)
    if (
        config.get("modo_adaptativo", False)
        and limiar_area <= 2
        and config.get("modo_deteccao", "preenchido") == "preenchido"
    ):
        # Une somente gaps diagonais/adjacentes de uma máscara muito pequena;
        # o kernel 2x2 não engorda bordas como o fechamento 3x3.
        mascara = cv2.morphologyEx(
            mascara, cv2.MORPH_CLOSE, KERNEL_MORFOLOGIA_PEQUENA, iterations=1
        )
        mascara = cv2.bitwise_and(mascara, mascara_fov)

    if config.get("modo_deteccao", "preenchido") == "contorno":
        # Contornos de 1–2 pixels podem ter pequenas falhas por antialiasing.
        # O fechamento conecta gaps curtos sem transformar a borda em uma área
        # preenchida. Reaplicamos o FOV circular para não vazar para fora dele.
        mascara = cv2.morphologyEx(
            mascara, cv2.MORPH_CLOSE, KERNEL_MORFOLOGIA, iterations=1
        )
        mascara = cv2.bitwise_and(mascara, mascara_fov)

        # Para uma linha fina, contourArea pode ser quase zero ou fragmentado.
        # Componentes conectados usam os pixels reais da linha e o bounding box
        # preserva o centro geométrico do alvo mesmo com um pequeno gap restante.
        quantidade, _rotulos, estatisticas, _centroides = (
            cv2.connectedComponentsWithStats(mascara, connectivity=8)
        )
        for indice in range(1, quantidade):
            area_pixels = int(estatisticas[indice, cv2.CC_STAT_AREA])
            if area_pixels < limiar_area:
                continue
            x = int(estatisticas[indice, cv2.CC_STAT_LEFT])
            y = int(estatisticas[indice, cv2.CC_STAT_TOP])
            largura_contorno = int(estatisticas[indice, cv2.CC_STAT_WIDTH])
            altura_contorno = int(estatisticas[indice, cv2.CC_STAT_HEIGHT])
            mascara_regiao = np.where(_rotulos == indice, 255, 0).astype(np.uint8)
            if formato_deve_ser_ignorado(
                None,
                mascara_regiao,
                largura_contorno,
                altura_contorno,
                config,
            ):
                continue
            candidatos.append(
                (
                    x + largura_contorno / 2.0,
                    y + altura_contorno / 2.0,
                    float(area_pixels),
                    float(largura_contorno),
                    float(altura_contorno),
                )
            )
    else:
        contornos, _ = cv2.findContours(
            mascara, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        for contorno in contornos:
            area = cv2.contourArea(contorno)
            x, y, largura_contorno, altura_contorno = cv2.boundingRect(contorno)
            # contourArea subestima quadrados e pontos antialiased de poucos pixels.
            # A máscara binária representa melhor a área realmente detectada.
            area_pixels = int(
                cv2.countNonZero(
                    mascara[y : y + altura_contorno, x : x + largura_contorno]
                )
            )
            area = max(float(area), float(area_pixels))
            if area_pixels < limiar_area:
                continue
            if formato_deve_ser_ignorado(
                contorno,
                None,
                largura_contorno,
                altura_contorno,
                config,
            ):
                continue
            candidatos.append(
                (
                    x + largura_contorno / 2.0,
                    y + altura_contorno / 2.0,
                    area,
                    float(largura_contorno),
                    float(altura_contorno),
                )
            )

    if not candidatos:
        return None

    prioridade_centro = float(config.get("prioridade_centro", 0.85))
    prioridade_centro = limitar(prioridade_centro, 0.0, 1.0)
    centro_maximo = max(
        1.0,
        (largura * 0.5) ** 2 + (altura * 0.5) ** 2,
    )
    area_maxima = max(
        1.0,
        math.pi * (min(largura, altura) * 0.5) ** 2,
    )

    def distancia_centro_quadrada(alvo):
        return (alvo[0] - largura * 0.5) ** 2 + (
            alvo[1] - altura * 0.5
        ) ** 2

    def pontuacao_candidato(alvo):
        centro_normalizado = min(
            1.0, distancia_centro_quadrada(alvo) / centro_maximo
        )
        # Área só desempata candidatos quando a prioridade central não é 100%.
        area_normalizada = min(1.0, max(0.0, alvo[2]) / area_maxima)
        pontuacao = prioridade_centro * centro_normalizado
        pontuacao += (1.0 - prioridade_centro) * (1.0 - area_normalizada)
        if referencia is not None:
            referencia_x, referencia_y = referencia
            distancia_referencia = (alvo[0] - referencia_x) ** 2 + (
                alvo[1] - referencia_y
            ) ** 2
            referencia_normalizada = min(
                1.0, distancia_referencia / centro_maximo
            )
            # O alvo já associado recebe peso temporal forte, enquanto o
            # centro e a força da região ficam como correções secundárias.
            peso_continuidade = 0.72 + 0.14 * prioridade_centro
            area_referencia = max(
                1.0, float(config.get("area_minima", 4)) * 3.0
            )
            confianca = min(
                1.0, max(0.0, float(alvo[2])) / area_referencia
            )
            pontuacao = (
                referencia_normalizada * peso_continuidade
                + centro_normalizado * (1.0 - peso_continuidade)
                - confianca * 0.12
            )
        return pontuacao

    candidatos_validos = candidatos
    if referencia is not None:
        referencia_x, referencia_y = referencia
        limite_config = float(config["distancia_reaquisicao"])
        if config.get("modo_adaptativo", False):
            limite_config = limitar(limite_config + 80.0, 160.0, 260.0)
        candidatos_validos = []
        for alvo in candidatos:
            largura_alvo = max(1.0, float(alvo[3]))
            altura_alvo = max(1.0, float(alvo[4]))
            raio_associacao = max(
                24.0,
                math.hypot(largura_alvo, altura_alvo) * 0.35,
            )
            limite = max(raio_associacao, min(limite_config, 180.0))
            distancia_quadrada = (alvo[0] - referencia_x) ** 2 + (
                alvo[1] - referencia_y
            ) ** 2
            if distancia_quadrada <= limite * limite:
                candidatos_validos.append(alvo)

        if not candidatos_validos:
            # Reaquisição rápida, semelhante ao Prime Aim: um candidato
            # suficientemente forte e ainda dentro do FOV pode substituir a
            # referência perdida sem esperar vários ciclos de confirmação.
            candidatos_desafiantes = []
            area_referencia = max(
                1.0, float(area_minima_efetiva(config)) * 2.0
            )
            for alvo in candidatos:
                distancia_centro = min(
                    1.0, distancia_centro_quadrada(alvo) / centro_maximo
                )
                confianca = min(
                    1.0, max(0.0, float(alvo[2])) / area_referencia
                )
                limiar_confianca = (
                    0.10 if config.get("modo_adaptativo", False) else 0.25
                )
                if confianca >= limiar_confianca and distancia_centro <= 0.90:
                    candidatos_desafiantes.append(alvo)
            if candidatos_desafiantes:
                candidatos_validos = candidatos_desafiantes
            else:
                return None

    return min(candidatos_validos, key=pontuacao_candidato)


def configuracao_mudou_alvo(antiga, nova):
    return (
        antiga["cor_hex"] != nova["cor_hex"]
        or antiga["tolerancia_rgb"] != nova["tolerancia_rgb"]
        or antiga.get("offset_vertical_px", 0)
        != nova.get("offset_vertical_px", 0)
        or antiga.get("prioridade_centro", 0.85)
        != nova.get("prioridade_centro", 0.85)
        or antiga.get("ignorar_barras", True)
        != nova.get("ignorar_barras", True)
        or antiga.get("ignorar_triangulos_invertidos", True)
        != nova.get("ignorar_triangulos_invertidos", True)
        or antiga["fov_diametro"] != nova["fov_diametro"]
        or antiga.get("zona_exclusao_diametro", 0)
        != nova.get("zona_exclusao_diametro", 0)
        or antiga.get("monitor_selecionado", "principal")
        != nova.get("monitor_selecionado", "principal")
    )


