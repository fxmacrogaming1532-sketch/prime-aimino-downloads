@echo off
setlocal
cd /d "%~dp0"
:loop
prime_aimino_agent.exe run --interval 1
timeout /t 5 /nobreak >nul
goto loop
