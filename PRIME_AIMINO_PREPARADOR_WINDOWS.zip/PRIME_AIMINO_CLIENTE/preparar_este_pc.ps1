$ErrorActionPreference = "Stop"
$agentDir = Split-Path -Parent $MyInvocation.MyCommand.Path

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $agentDir "instalar_agente_silencioso.ps1") -StartNow
if ($LASTEXITCODE -ne 0) { throw "Não foi possível registrar o agente silencioso." }

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $agentDir "registrar_ativacao_automatica.ps1")
if ($LASTEXITCODE -ne 0) { throw "Não foi possível registrar a ativação automática." }

$statusPath = Join-Path $env:LOCALAPPDATA "PRIME AIMINO\preparo.json"
$versionPath = Join-Path $agentDir "agent_version.json"
$packageVersion = if (Test-Path $versionPath) { [string](Get-Content -LiteralPath $versionPath -Raw | ConvertFrom-Json).version } else { "0.0.0" }
New-Item -ItemType Directory -Path (Split-Path -Parent $statusPath) -Force | Out-Null
@{ preparedAt = (Get-Date).ToUniversalTime().ToString("o"); version = $packageVersion } | ConvertTo-Json | Set-Content -Path $statusPath -Encoding UTF8
