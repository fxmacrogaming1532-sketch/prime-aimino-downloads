"""Agente local PRIME AIMINO.

O agente é o único componente que conversa com o rastreador e com a porta serial.
Ele não aceita conexões de entrada e só realiza requisições HTTPS de saída ao painel.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any


# Em desenvolvimento, os arquivos ficam em agente_web e o projeto é a pasta pai.
# No EXE PyInstaller, __file__ pode apontar para _internal/_MEIPASS; todos os
# dados persistentes precisam ficar ao lado do executável instalado.
if getattr(sys, "frozen", False):
    AGENT_DIR = Path(sys.executable).resolve().parent
    PROJECT_DIR = AGENT_DIR
else:
    AGENT_DIR = Path(__file__).resolve().parent
    # O pacote Python instalado também contém sua própria configuração.
    # Nesse caso, não subir para uma pasta externa do repositório.
    PROJECT_DIR = AGENT_DIR if (AGENT_DIR / "config_rastreador.json").exists() else AGENT_DIR.parent
sys.path.insert(0, str(PROJECT_DIR))
from agent_version import AGENT_VERSION
STATE_PATH = AGENT_DIR / "agent_state.json"
UPDATE_SCRIPT = AGENT_DIR / "atualizar_agente.ps1"
UPDATE_CHECK_INTERVAL_SECONDS = 600.0
RUN_LOCK_PATH = AGENT_DIR / "agent_run.lock"
LOG_PATH = AGENT_DIR / "agent.log"
CONFIG_PATH = PROJECT_DIR / "config_rastreador.json"
PAUSE_PATH = PROJECT_DIR / "estado_pausa_rastreador.json"
APP_PATH = PROJECT_DIR / "appgeral.py"
PACKAGED_TRACKER_PATH = AGENT_DIR / "tracker" / "prime_aimino_tracker.exe"
ACCESS_SAFETY_SECONDS = 90
TARGET_COLOR_PATTERN = re.compile(r"^#[0-9A-Fa-f]{6}$")
SUPPORTED_PAUSE_HOTKEYS = frozenset({"none", "f6", "f7", "f8", "f9", "f10", "mouse4", "mouse5"})
MOVEMENT_PROFILE_VALUES = {
  "reto_suave": {"humanizacao_forca": 0.0, "humanizacao_suavizacao": 0.075, "humanizacao_duracao": 18, "microtremor_px": 0.0},
  "natural": {"humanizacao_forca": 0.36, "humanizacao_suavizacao": 0.075, "humanizacao_duracao": 18, "microtremor_px": 0.15},
  "mao_tremula": {"humanizacao_forca": 0.58, "humanizacao_suavizacao": 0.12, "humanizacao_duracao": 10, "microtremor_px": 0.55},
  "curvas_fortes": {"humanizacao_forca": 0.82, "humanizacao_suavizacao": 0.055, "humanizacao_duracao": 30, "microtremor_px": 0.22},
}


class AgentError(RuntimeError):
    """Falha operacional que pode ser mostrada com segurança ao operador."""


def log_event(level: str, message: str) -> None:
    """Mantém um diagnóstico local limitado, sem escrever tokens ou dados serializados."""
    try:
        if LOG_PATH.exists() and LOG_PATH.stat().st_size > 512_000:
            LOG_PATH.replace(LOG_PATH.with_suffix(".previous.log"))
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with LOG_PATH.open("a", encoding="utf-8") as output:
            output.write(f"[{stamp}] {level}: {message[:500]}\n")
    except OSError:
        pass


def _load_dpapi():
    try:
        import win32crypt  # type: ignore
    except ImportError as error:
        raise AgentError("O pacote do agente está incompleto: reinstale pelo instalador oficial para restaurar as dependências.") from error
    return win32crypt


def _dpapi_bytes(result: Any) -> bytes:
    if isinstance(result, (bytes, bytearray)):
        return bytes(result)
    for value in result:
        if isinstance(value, (bytes, bytearray)):
            return bytes(value)
    raise AgentError("O Windows não retornou dados protegidos pelo DPAPI.")


def protect(value: str) -> str:
    encrypted = _dpapi_bytes(_load_dpapi().CryptProtectData(value.encode("utf-8"), "prime-aimino-agent", None, None, None, 0))
    return base64.b64encode(encrypted).decode("ascii")


def unprotect(value: str) -> str:
    encrypted = base64.b64decode(value.encode("ascii"))
    return _dpapi_bytes(_load_dpapi().CryptUnprotectData(encrypted, None, None, None, 0)).decode("utf-8")


def load_state() -> dict[str, Any]:
    if not STATE_PATH.exists():
        return {}
    try:
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise AgentError("O arquivo local do agente está inválido. Remova agent_state.json e pareie novamente.") from error


def save_state(state: dict[str, Any]) -> None:
    temporary = STATE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(STATE_PATH)


def rpc(base_url: str, procedure: str, input_data: dict[str, Any]) -> dict[str, Any]:
    """Chama um procedimento tRPC pelo protocolo HTTP sem expor segredos em logs."""
    endpoint = f"{base_url.rstrip('/')}/api/trpc/{procedure}"
    payload = json.dumps({"json": input_data}).encode("utf-8")
    request = urllib.request.Request(endpoint, data=payload, headers={"content-type": "application/json", "accept": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        try:
            body = json.loads(error.read().decode("utf-8"))
            message = body.get("error", {}).get("json", {}).get("message") or "Painel recusou a solicitação."
        except Exception:
            message = f"Falha HTTP {error.code} ao comunicar com o painel."
        raise AgentError(message) from error
    except (urllib.error.URLError, TimeoutError) as error:
        raise AgentError("Painel indisponível. O agente permanecerá somente no modo offline permitido.") from error

    if "error" in body:
        raise AgentError(body["error"].get("json", {}).get("message") or "Painel recusou a solicitação.")
    result = body.get("result", {}).get("data", {})
    return result.get("json", result)


def agent_identity() -> tuple[str, str]:
    """Gera uma chave pública Ed25519 do agente e devolve PEM/fingerprint."""
    try:
        from cryptography.hazmat.primitives import serialization  # type: ignore
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # type: ignore
    except ImportError as error:
        raise AgentError("O pacote do agente está incompleto: reinstale pelo instalador oficial para restaurar a criptografia.") from error

    private_key = Ed25519PrivateKey.generate()
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    fingerprint = hashlib.sha256(public_pem.encode("utf-8")).hexdigest()
    return public_pem, protect(private_pem) + "." + fingerprint


def pair(args: argparse.Namespace) -> None:
    code = args.code.replace("-", "").strip().upper()
    if len(code) != 10:
        raise AgentError("O código de pareamento deve ter 10 caracteres.")
    public_pem, protected_private = agent_identity()
    fingerprint = protected_private.rsplit(".", 1)[1]
    result = rpc(args.url, "tracker.pairAgent", {
        "code": code,
        "displayName": args.name,
        "platform": "Windows",
        "agentVersion": AGENT_VERSION,
        "publicKeyPem": public_pem,
        "keyFingerprint": fingerprint,
    })
    state = {
        "backend_url": args.url.rstrip("/"),
        "device_id": result["deviceId"],
        "refresh_token_protected": protect(result["refreshToken"]),
        "private_key_protected": protected_private.rsplit(".", 1)[0],
        "access_token_protected": protect(result["accessToken"]),
        "access_token_received_at": int(time.time()),
        "license_expires_at": result.get("licenseExpiresAt"),
        "offline_grace_hours": int(result.get("offlineGraceHours", 0)),
        "last_authenticated_at": int(time.time()),
        "profile_revision": 0,
        "tracker_pid": None,
    }
    save_state(state)
    print(f"Agente pareado com sucesso. Dispositivo: {state['device_id']}")


def activate_uri(args: argparse.Namespace) -> None:
    parsed = urllib.parse.urlparse(args.uri)
    if parsed.scheme.lower() != "primeaimino" or parsed.netloc.lower() != "activate":
        raise AgentError("Link de ativação inválido.")
    values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    token = values.get("token", [""])[0].strip()
    backend = values.get("backend", [""])[0].strip()
    if not token or not backend:
        raise AgentError("Link de ativação incompleto.")
    activate(argparse.Namespace(token=token, url=backend, name=args.name))


def activate(args: argparse.Namespace) -> None:
    token = args.token.strip()
    if len(token) < 40:
        raise AgentError("A autorização de ativação está inválida ou incompleta.")
    public_pem, protected_private = agent_identity()
    fingerprint = protected_private.rsplit(".", 1)[1]
    result = rpc(args.url, "tracker.activateAgent", {
        "token": token,
        "displayName": args.name,
        "platform": "Windows",
        "agentVersion": AGENT_VERSION,
        "publicKeyPem": public_pem,
        "keyFingerprint": fingerprint,
    })
    state = {
        "backend_url": args.url.rstrip("/"),
        "device_id": result["deviceId"],
        "refresh_token_protected": protect(result["refreshToken"]),
        "private_key_protected": protected_private.rsplit(".", 1)[0],
        "access_token_protected": protect(result["accessToken"]),
        "access_token_received_at": int(time.time()),
        "license_expires_at": result.get("licenseExpiresAt"),
        "offline_grace_hours": int(result.get("offlineGraceHours", 0)),
        "last_authenticated_at": int(time.time()),
        "profile_revision": 0,
        "tracker_pid": None,
    }
    save_state(state)
    print(f"Agente ativado com sucesso. Dispositivo: {state['device_id']}")


def ensure_access(state: dict[str, Any]) -> tuple[dict[str, Any], str]:
    received_at = int(state.get("access_token_received_at", 0))
    if received_at + ACCESS_SAFETY_SECONDS > int(time.time()):
        return state, unprotect(state["access_token_protected"])
    refresh_token = unprotect(state["refresh_token_protected"])
    result = rpc(state["backend_url"], "devices.refreshAgentSession", {"refreshToken": refresh_token})
    state["refresh_token_protected"] = protect(result["refreshToken"])
    state["access_token_protected"] = protect(result["accessToken"])
    state["access_token_received_at"] = int(time.time())
    state["last_authenticated_at"] = int(time.time())
    state["offline_grace_hours"] = int(result.get("offlineGraceHours", state.get("offline_grace_hours", 0)))
    state["license_expires_at"] = result.get("licenseExpiresAt")
    save_state(state)
    return state, result["accessToken"]


def offline_allowed(state: dict[str, Any]) -> bool:
  grace_seconds = int(state.get("offline_grace_hours", 0)) * 3600
  return grace_seconds > 0 and int(time.time()) <= int(state.get("last_authenticated_at", 0)) + grace_seconds


def valid_target_color(value: Any) -> str | None:
  """Retorna a cor ativa normalizada ou None quando a detecção deve ficar bloqueada."""
  if not isinstance(value, str):
    return None
  color = value.strip().upper()
  return color if TARGET_COLOR_PATTERN.fullmatch(color) else None


def normalize_remote_config(config: Any) -> dict[str, Any]:
  """Mantém atalhos no painel, mas nunca deixa o rastreador consumir cores antigas."""
  if not isinstance(config, dict):
    raise AgentError("O painel retornou uma configuração de rastreador inválida.")
  normalized = dict(config)
  # Preserva o identificador do perfil sonoro para o rastreador tocar o WAV
  # correspondente; somente o beep padrão do Windows é proibido.
  perfil_som = str(normalized.get("perfil_som", "som_01")).strip().lower()
  normalized["perfil_som"] = perfil_som if re.fullmatch(r"som_(?:[1-9]|[12][0-9]|30)", perfil_som) else "som_01"
  active_color = valid_target_color(normalized.get("cor_hex"))
  normalized["cor_hex"] = active_color or ""
  normalized["cores_salvas"] = [active_color] if active_color else []
  hotkey = str(normalized.get("hotkey_pausa", "none")).strip().lower()
  normalized["hotkey_pausa"] = hotkey if hotkey in SUPPORTED_PAUSE_HOTKEYS else "none"
  profile = str(normalized.get("perfil_movimento", "personalizado")).strip().lower()
  if profile in MOVEMENT_PROFILE_VALUES:
    normalized["perfil_movimento"] = profile
    normalized.update(MOVEMENT_PROFILE_VALUES[profile])
  else:
    normalized["perfil_movimento"] = "personalizado"
  return normalized


def active_target_color() -> str | None:
  """Lê somente a cor corrente; nunca usa cores salvas como conjunto de detecção."""
  try:
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
  except (OSError, json.JSONDecodeError):
    return None
  return valid_target_color(config.get("cor_hex"))


def sync(args: argparse.Namespace) -> None:
    state = load_state()
    if not state:
        raise AgentError("Agente não pareado. Execute o comando 'pair' primeiro.")
    try:
        state, access_token = ensure_access(state)
        response = rpc(state["backend_url"], "tracker.pullForAgent", {"accessToken": access_token})
        revision = int(response["revision"])
        if revision < int(state.get("profile_revision", 0)):
            raise AgentError("O painel retornou uma revisão anterior; a configuração local foi preservada.")
        existing_config: dict[str, Any] = {}
        try:
            existing_config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass
        remote_config = normalize_remote_config(response.get("config"))
        merged_config = {**existing_config, **remote_config}
        temporary = CONFIG_PATH.with_suffix(".web.tmp")
        temporary.write_text(json.dumps(merged_config, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(CONFIG_PATH)
        state["profile_revision"] = revision
        state["cached_config"] = remote_config
        save_state(state)
        heartbeat(state, "stopped")
        print(f"Ajustes sincronizados com segurança: revisão {revision}.")
    except AgentError as error:
        try:
            heartbeat(state, "error", str(error))
        except AgentError:
            pass
        raise


def local_serial_diagnostic() -> tuple[str | None, str, str | None]:
    """Lê somente a configuração local; a porta serial permanece isolada do navegador."""
    try:
        config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        port = config.get("porta_serial") or config.get("porta")
        if isinstance(port, str) and port.strip():
            return port.strip()[:64], "configured", None
        return None, "unconfigured", None
    except (OSError, json.JSONDecodeError):
        return None, "error", "Não foi possível ler a configuração serial local."


def tracker_running(state: dict[str, Any]) -> bool:
    pid = state.get("tracker_pid")
    if not isinstance(pid, int) or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def pause_enabled() -> bool:
    try:
        return bool(json.loads(PAUSE_PATH.read_text(encoding="utf-8")).get("pausado", False))
    except (OSError, json.JSONDecodeError):
        return False


def set_pause(enabled: bool) -> None:
    temporary = PAUSE_PATH.with_suffix(".web.tmp")
    temporary.write_text(json.dumps({"pausado": enabled}) + "\n", encoding="utf-8")
    temporary.replace(PAUSE_PATH)


def tracker_state(state: dict[str, Any]) -> str:
    if pause_enabled() and tracker_running(state):
        return "paused"
    return "running" if tracker_running(state) else "stopped"


def acquire_run_lock() -> None:
    try:
        descriptor = os.open(str(RUN_LOCK_PATH), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        try:
            previous_pid = int(RUN_LOCK_PATH.read_text(encoding="utf-8").strip())
            os.kill(previous_pid, 0)
        except (OSError, ValueError):
            RUN_LOCK_PATH.unlink(missing_ok=True)
            return acquire_run_lock()
        raise AgentError("O agente em segundo plano já está em execução neste computador.")
    with os.fdopen(descriptor, "w", encoding="utf-8") as lock_file:
        lock_file.write(str(os.getpid()))


def release_run_lock() -> None:
    try:
        if RUN_LOCK_PATH.exists() and RUN_LOCK_PATH.read_text(encoding="utf-8").strip() == str(os.getpid()):
            RUN_LOCK_PATH.unlink()
    except OSError:
        pass


def heartbeat(state: dict[str, Any], tracker_state: str, last_error: str | None = None) -> None:
    state, access_token = ensure_access(state)
    port, serial_state, config_error = local_serial_diagnostic()
    safe_error = (last_error or config_error or "").strip()[:500] or None
    rpc(state["backend_url"], "devices.heartbeat", {
        "accessToken": access_token,
        "agentVersion": AGENT_VERSION,
        "trackerState": tracker_state,
        "serialPort": port,
        "serialState": serial_state,
        "lastError": safe_error,
        "configRevision": int(state.get("profile_revision", 0)),
    })


def tracker_command() -> list[str]:
    """Usa o rastreador instalado junto do agente; nunca depende do py.exe global."""
    if PACKAGED_TRACKER_PATH.is_file():
        return [str(PACKAGED_TRACKER_PATH), "--tracker"]
    return [sys.executable, str(APP_PATH), "--tracker"]


def start_tracker(args: argparse.Namespace) -> None:
    state = load_state()
    if not state:
        raise AgentError("Agente não pareado.")
    try:
        sync(args)
        state = load_state()
    except AgentError:
        if not offline_allowed(state):
            raise
        print("Painel indisponível; usando somente a última configuração válida dentro da tolerância offline.")
    if not active_target_color():
        if tracker_running(state):
            set_pause(True)
            heartbeat(state, "paused", "Movimento bloqueado: nenhuma cor de alvo válida está configurada.")
        else:
            heartbeat(state, "stopped", "Movimento bloqueado: nenhuma cor de alvo válida está configurada.")
        raise AgentError("Movimento bloqueado: nenhuma cor de alvo válida está configurada.")
    if tracker_running(state):
        set_pause(False)
        heartbeat(state, "running")
        print("Rastreador já estava ativo; pausa removida.")
        return
    set_pause(False)
    process = subprocess.Popen(tracker_command(), cwd=str(PROJECT_DIR), creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    state["tracker_pid"] = process.pid
    save_state(state)
    try:
        heartbeat(state, "running")
    except AgentError:
        pass
    print(f"Rastreador iniciado pelo agente (PID {process.pid}).")


def stop_tracker(_: argparse.Namespace) -> None:
    state = load_state()
    pid = state.get("tracker_pid")
    if pid:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, text=True, check=False)
    state["tracker_pid"] = None
    set_pause(False)
    save_state(state)
    try:
        heartbeat(state, "stopped")
    except AgentError:
        pass
    print("Rastreador interrompido. Se a placa estava em uso, o firmware aplica a liberação de segurança.")


def execute_command(args: argparse.Namespace, state: dict[str, Any], command: str) -> str:
    if command == "sync":
        sync(args)
        return "Ajustes sincronizados."
    if command == "start":
        start_tracker(args)
        return "Rastreador iniciado."
    if command == "pause":
        # Atualiza a preferência de som antes de sinalizar a pausa. O comando
        # permanece estritamente seguro: ele não inicia rastreador ou serial.
        try:
            sync(args)
        except AgentError:
            pass
        set_pause(True)
        state = load_state()
        heartbeat(state, "paused")
        return "Rastreador pausado."
    if command == "resume":
        if not active_target_color():
            set_pause(True)
            state = load_state()
            heartbeat(state, "paused", "Movimento bloqueado: nenhuma cor de alvo válida está configurada.")
            raise AgentError("Movimento bloqueado: nenhuma cor de alvo válida está configurada.")
        set_pause(False)
        state = load_state()
        heartbeat(state, "running" if tracker_running(state) else "stopped")
        return "Rastreador retomado."
    if command == "stop":
        stop_tracker(args)
        return "Rastreador interrompido."
    raise AgentError("Comando remoto não reconhecido.")


def start_update_check() -> None:
    """Inicia uma atualização silenciosa fora do processo do agente.

    A falha de rede é ignorada e nunca impede o polling, a sincronização ou o
    rastreador local.
    """
    if not UPDATE_SCRIPT.exists() or os.name != "nt":
        return
    try:
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(
            [
                "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden", "-File", str(UPDATE_SCRIPT),
                "-AgentDir", str(AGENT_DIR), "-Apply", "-ParentPid", str(os.getpid()),
            ],
            cwd=str(AGENT_DIR), creationflags=flags, close_fds=True,
        )
    except (OSError, subprocess.SubprocessError) as error:
        log_event("WARNING", f"Não foi possível iniciar a verificação de atualização: {type(error).__name__}")


def run_background(args: argparse.Namespace) -> None:
    state = load_state()
    if not state:
        raise AgentError("Agente não pareado. Execute o comando 'pair' primeiro.")
    interval = max(1.0, min(float(args.interval), 30.0))
    acquire_run_lock()
    print(f"Agente em segundo plano iniciado. Consultando comandos a cada {interval:g} s.")
    ultima_verificacao_atualizacao = 0.0
    try:
        while True:
            state = load_state()
            agora = time.time()
            if agora - ultima_verificacao_atualizacao >= UPDATE_CHECK_INTERVAL_SECONDS:
                ultima_verificacao_atualizacao = agora
                start_update_check()
            try:
                state, access_token = ensure_access(state)
                response = rpc(state["backend_url"], "tracker.pollCommands", {"accessToken": access_token})
                if not response.get("movementAllowed", True) and tracker_running(state):
                    set_pause(True)
                    heartbeat(load_state(), "paused", "Movimento bloqueado: nenhuma cor de alvo válida está configurada.")
                for command in response.get("commands", []):
                    command_id = str(command.get("id", ""))
                    try:
                        result = execute_command(args, state, str(command.get("command", "")))
                        rpc(state["backend_url"], "tracker.completeCommand", {"accessToken": access_token, "commandId": command_id, "status": "completed", "resultMessage": result})
                    except AgentError as error:
                        rpc(state["backend_url"], "tracker.completeCommand", {"accessToken": access_token, "commandId": command_id, "status": "failed", "resultMessage": str(error)[:500]})
                        heartbeat(load_state(), "error", str(error))
                    except Exception as error:
                        safe_message = f"Falha inesperada ({type(error).__name__}); consulte agent.log."
                        log_event("ERROR", f"Comando {command_id} falhou: {type(error).__name__}: {error}")
                        rpc(state["backend_url"], "tracker.completeCommand", {"accessToken": access_token, "commandId": command_id, "status": "failed", "resultMessage": safe_message})
                        heartbeat(load_state(), "error", safe_message)
                heartbeat(load_state(), tracker_state(load_state()))
            except AgentError as error:
                print(f"AVISO: {error}", file=sys.stderr)
                log_event("WARNING", str(error))
            except Exception as error:
                safe_message = f"Falha inesperada ({type(error).__name__}); consulte agent.log."
                print(f"AVISO: {safe_message}", file=sys.stderr)
                log_event("ERROR", f"Laço principal: {type(error).__name__}: {error}")
                try:
                    heartbeat(load_state(), "error", safe_message)
                except Exception as heartbeat_error:
                    log_event("WARNING", f"Não foi possível reportar a falha: {type(heartbeat_error).__name__}")
            time.sleep(interval)
    finally:
        release_run_lock()


def status(_: argparse.Namespace) -> None:
    state = load_state()
    if not state:
        print("Agente não pareado.")
        return
    print(json.dumps({
        "device_id": state.get("device_id"),
        "profile_revision": state.get("profile_revision", 0),
        "tracker_pid": state.get("tracker_pid"),
        "offline_allowed": offline_allowed(state),
        "last_authenticated_at": state.get("last_authenticated_at"),
    }, ensure_ascii=False, indent=2))


def parser() -> argparse.ArgumentParser:
    command = argparse.ArgumentParser(description="Agente local PRIME AIMINO")
    sub = command.add_subparsers(dest="command", required=True)
    pair_command = sub.add_parser("pair", help="Pareia o agente uma única vez.")
    pair_command.add_argument("--url", required=True, help="URL do painel web")
    pair_command.add_argument("--code", required=True, help="Código de 10 caracteres gerado no painel")
    pair_command.add_argument("--name", default=os.environ.get("COMPUTERNAME", "PC Windows"), help="Nome exibido para este computador")
    pair_command.set_defaults(handler=pair)
    activation = sub.add_parser("activate", help="Ativa automaticamente o agente com uma autorização curta.")
    activation.add_argument("--url", required=True, help="URL do painel web")
    activation.add_argument("--token", required=True, help="Autorização curta emitida após o login")
    activation.add_argument("--name", default=os.environ.get("COMPUTERNAME", "PC Windows"), help="Nome exibido para este computador")
    activation.set_defaults(handler=activate)
    activation_uri = sub.add_parser("activate-uri", help="Ativa diretamente a partir de um link primeaimino://.")
    activation_uri.add_argument("uri", help="Link primeaimino:// recebido do painel")
    activation_uri.add_argument("--name", default=os.environ.get("COMPUTERNAME", "PC Windows"), help="Nome exibido para este computador")
    activation_uri.set_defaults(handler=activate_uri)
    sub.add_parser("sync", help="Baixa o perfil autorizado e atualiza a configuração local.").set_defaults(handler=sync)
    sub.add_parser("start", help="Sincroniza e inicia o rastreador atual.").set_defaults(handler=start_tracker)
    sub.add_parser("stop", help="Interrompe o rastreador iniciado pelo agente.").set_defaults(handler=stop_tracker)
    sub.add_parser("status", help="Mostra o estado local sem exibir tokens.").set_defaults(handler=status)
    background = sub.add_parser("run", help="Permanece em segundo plano e executa comandos autorizados do painel.")
    background.add_argument("--interval", type=float, default=3.0, help="Intervalo de consulta em segundos (1 a 30).")
    background.set_defaults(handler=run_background)
    return command


def main() -> int:
    try:
        # Duplo clique no EXE deve iniciar o agente em segundo plano. O
        # protocolo de ativação e a tarefa agendada continuam passando seus
        # subcomandos explicitamente.
        if len(sys.argv) == 1:
            sys.argv.append("run")
        args = parser().parse_args()
        args.handler(args)
        return 0
    except AgentError as error:
        print(f"ERRO: {error}", file=sys.stderr)
        log_event("ERROR", str(error))
        return 2
    except Exception as error:
        safe_message = f"Falha inesperada ({type(error).__name__}); consulte agent.log."
        print(f"ERRO: {safe_message}", file=sys.stderr)
        log_event("ERROR", f"Execução finalizada: {type(error).__name__}: {error}")
        return 1
    except KeyboardInterrupt:
        print("Operação cancelada.")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
