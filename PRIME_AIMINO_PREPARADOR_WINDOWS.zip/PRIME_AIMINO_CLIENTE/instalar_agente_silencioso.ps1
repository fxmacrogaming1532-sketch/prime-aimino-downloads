param([switch]$StartNow)

$ErrorActionPreference = "Stop"
try {
  $agentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
  $installRoot = [IO.Path]::GetFullPath($agentDir).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
  $agentScript = Join-Path $installRoot "prime_aimino_agent.py"
  $requirements = Join-Path $installRoot "requirements_agent.txt"
  if (-not (Test-Path -LiteralPath $agentScript -PathType Leaf)) { throw "prime_aimino_agent.py não encontrado na pasta escolhida." }

  function Test-Python($candidate, [string[]]$prefixArgs) {
    if (-not $candidate -or -not (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $false }
    try {
      & $candidate @prefixArgs -c "import sys; print(sys.executable)" *> $null
      return ($LASTEXITCODE -eq 0)
    } catch { return $false }
  }

  $python = $null
  $prefix = @()
  $candidates = @()
  try { $candidates += (Get-Command python.exe -CommandType Application -ErrorAction Stop).Source } catch {}
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe"),
    (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"),
    (Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe"),
    (Join-Path $env:ProgramFiles "Python311\python.exe"),
    (Join-Path $env:ProgramFiles "Python312\python.exe")
  )
  foreach ($candidate in ($candidates | Where-Object { $_ } | Select-Object -Unique) ) {
    if (Test-Python $candidate @()) { $python = $candidate; break }
  }
  if (-not $python) {
    try {
      $py = (Get-Command py.exe -CommandType Application -ErrorAction Stop).Source
      if (Test-Python $py @("-3")) { $python = $py; $prefix = @("-3") }
    } catch {}
  }
  if (-not $python) { throw "Python 3 não foi encontrado. Instale Python 3.11+ para o usuário atual e execute este preparador novamente." }

  if (Test-Path -LiteralPath $requirements -PathType Leaf) {
    & $python @prefix -m pip install --user --disable-pip-version-check -r $requirements *> (Join-Path $installRoot "python-install.log")
    if ($LASTEXITCODE -ne 0) { throw "Não foi possível instalar as dependências Python. Consulte python-install.log." }
  }
  $runtime = @{ executable = $python; prefix = $prefix; script = $agentScript } | ConvertTo-Json
  $runtime | Set-Content -LiteralPath (Join-Path $installRoot "python_runtime.json") -Encoding UTF8

  # Tarefas agendadas iniciadas no desktop não devem abrir uma janela preta.
  # Mantemos o python.exe no runtime para comandos/diagnóstico e usamos
  # pythonw.exe somente para o processo persistente em segundo plano.
  $pythonw = Join-Path (Split-Path -Parent $python) "pythonw.exe"
  if (-not (Test-Path -LiteralPath $pythonw -PathType Leaf)) { $pythonw = $python }

  $userSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  $taskName = "PRIME AIMINO Agent - $userSid"
  Get-CimInstance Win32_Process -Filter "Name = 'prime_aimino_agent.exe'" -ErrorAction SilentlyContinue |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like "*prime_aimino_agent.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object { $_.TaskName -like "PRIME AIMINO Agent*" } |
    ForEach-Object { Unregister-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -Confirm:$false -ErrorAction SilentlyContinue }

  $taskArguments = (($prefix + @($agentScript, "run", "--interval", "3")) | ForEach-Object { '"' + $_ + '"' }) -join " "
  $action = New-ScheduledTaskAction -Execute $pythonw -Argument $taskArguments -WorkingDirectory $installRoot
  $logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
  $watchdogTrigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 3650)
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Days 365) -MultipleInstances IgnoreNew
  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($logonTrigger, $watchdogTrigger) -Settings $settings -Description "Agente Python local do PRIME AIMINO com watchdog." -Force | Out-Null
  if ($StartNow) { Start-ScheduledTask -TaskName $taskName }
  Write-Output "Agente Python registrado: $python"
} catch {
  $errorPath = Join-Path $agentDir "install-error.log"
  $_ | Out-File -LiteralPath $errorPath -Encoding UTF8 -Force
  Write-Error $_
  exit 1
}
