// Firmware incremental corrigido para Pro Micro / ATmega32U4.
// Mantém o protocolo existente: MOVE, CLICK LEFT/RIGHT, PRESS/RELEASE
// LEFT e HUMANIZE, além de PING/PONG.
//
// Importante: os IDs abaixo são mantidos por compatibilidade com a versão atual.
// Eles identificam o dispositivo USB como Logitech G402, mas não transformam a
// placa em um produto Logitech nem substituem uma licença/identidade USB própria.

// ANTES de tudo: define VID/PID customizados
#define HID_VID 0x046D
#define HID_PID 0xC077
#define HID_MANUFACTURER "Logitech"
#define HID_PRODUCT "G402 Gaming Mouse"

#include <Arduino.h>
#include <math.h>
#include <string.h>
#include <HID-Project.h>

// ==================== CONSTANTES BASE ====================

const unsigned long BAUD = 115200;

const float FRACAO_MIN = 0.55f;
const float FRACAO_MAX = 0.85f;
const float PENDENTE_MAXIMO = 140.0f;

const int MOVIMENTO_MAXIMO_BAIXO = 4;
const int MOVIMENTO_MAXIMO_PADRAO = 12;
const int MOVIMENTO_MAXIMO_ALTO = 18;

const unsigned long INTERVALO_MIN_MS = 1;
const unsigned long INTERVALO_MAX_MS = 5;

const float TREMOR_FREQ_BASE = 0.018f;
const float TREMOR_AMPLITUDE_MAX = 0.45f;
const float TREMOR_AMPLITUDE_MIN = 0.10f;

const float OVERSHOOT_PROB = 0.18f;
const float OVERSHOOT_FATOR = 1.12f;
const byte OVERSHOOT_TICKS = 3;

const float ZONA_MORTA_CHANCE = 0.12f;
const float MAGNITUDE_ALPHA = 0.12f;

// Se o PC travar com um botão HID pressionado, a placa libera o botão depois
// deste intervalo sem receber nenhum comando. O valor é maior que a pausa de
// 350 ms usada pelo teste de traçado no Paint.
const unsigned long SILENCIO_MAXIMO_MOUSE_MS = 3000UL;

// ==================== PARÂMETROS DE HUMANIZAÇÃO ====================

float humanizacaoForcaMaxima = 0.36f;
float humanizacaoSuavizacao = 0.075f;
byte humanizacaoTicksPorAlvo = 18;

// ==================== ESTADO DO MOVIMENTO ====================

float pendenteX = 0.0f;
float pendenteY = 0.0f;
unsigned long proximoTick = 0;

float ondaLateral = 0.0f;
float alvoOndaLateral = 0.0f;
byte ticksAteNovoAlvoLateral = 0;

float tremorFase = 0.0f;
float tremorFrequencia = TREMOR_FREQ_BASE;

bool emOvershoot = false;
byte overshootTickRestante = 0;
int overshootPorTickX = 0;
int overshootPorTickY = 0;
int overshootCorrigirX = 0;
int overshootCorrigirY = 0;

float mediaMagnitude = 8.0f;
int movimentoMaximoAtual = MOVIMENTO_MAXIMO_PADRAO;

bool direcaoXPositiva = true;
bool direcaoYPositiva = true;
bool primeiraDirecao = true;

bool mouseEsquerdoPressionado = false;
bool mouseDireitoPressionado = false;
unsigned long ultimoComandoSerial = 0;

// ==================== PRNG (LCG) ====================

unsigned long estadoAleatorio = 0x6D2B79F5UL;

// ==================== BUFFER SERIAL ====================

char buffer[40];
byte idx = 0;
bool bufferOverflow = false;

// ==================== FUNÇÕES AUXILIARES ====================

float proximoAleatorio() {
  estadoAleatorio = estadoAleatorio * 1664525UL + 1013904223UL;
  return ((float)((estadoAleatorio >> 16) & 0x7FFF) / 16383.5f) - 1.0f;
}

float proximoAleatorioPositivo() {
  estadoAleatorio = estadoAleatorio * 1664525UL + 1013904223UL;
  return (float)((estadoAleatorio >> 16) & 0x7FFF) / 32767.0f;
}

float limitarFloat(float valor, float minimo, float maximo) {
  if (valor < minimo) return minimo;
  if (valor > maximo) return maximo;
  return valor;
}

float limitarPendente(float valor) {
  if (valor > PENDENTE_MAXIMO) return PENDENTE_MAXIMO;
  if (valor < -PENDENTE_MAXIMO) return -PENDENTE_MAXIMO;
  return valor;
}

int arredondarFloat(float valor) {
  if (valor >= 0.0f) return (int)(valor + 0.5f);
  return (int)(valor - 0.5f);
}

int limitarMovimento(int valor) {
  if (valor > movimentoMaximoAtual) return movimentoMaximoAtual;
  if (valor < -movimentoMaximoAtual) return -movimentoMaximoAtual;
  return valor;
}

bool lerInt(const char*& texto, int& valor) {
  while (*texto == ' ') texto++;

  int sinal = 1;
  if (*texto == '-') {
    sinal = -1;
    texto++;
  } else if (*texto == '+') {
    texto++;
  }

  if (*texto < '0' || *texto > '9') return false;

  // O int do ATmega32U4 tem 16 bits. Acumular em long evita overflow
  // silencioso antes da conversão final.
  long resultado = 0;
  bool overflow = false;
  while (*texto >= '0' && *texto <= '9') {
    resultado = resultado * 10L + (long)(*texto - '0');
    if (resultado > 32768L) overflow = true;
    texto++;
  }

  if (overflow) return false;

  long valorAssinado = (long)sinal * resultado;
  if (valorAssinado < -32768L || valorAssinado > 32767L) return false;

  valor = (int)valorAssinado;
  return true;
}

bool fimDoComando(const char*& texto) {
  while (*texto == ' ') texto++;
  return *texto == '\0';
}

// ==================== HUMANIZAÇÃO PERPENDICULAR ====================

void reiniciarHumanizacao() {
  ondaLateral = 0.0f;
  alvoOndaLateral = 0.0f;
  ticksAteNovoAlvoLateral = 0;
}

void humanizarTrajetoriaPerpendicular(float& movimentoX, float& movimentoY) {
  float tamanho = sqrt(movimentoX * movimentoX + movimentoY * movimentoY);
  if (tamanho < 1.25f) return;

  if (ticksAteNovoAlvoLateral == 0) {
    alvoOndaLateral = proximoAleatorio();
    ticksAteNovoAlvoLateral = humanizacaoTicksPorAlvo;
  } else {
    ticksAteNovoAlvoLateral--;
  }

  ondaLateral += (alvoOndaLateral - ondaLateral) * humanizacaoSuavizacao;

  float proporcao = 0.12f + tamanho * 0.018f;
  if (proporcao > humanizacaoForcaMaxima) {
    proporcao = humanizacaoForcaMaxima;
  }

  float lateral = ondaLateral * proporcao;
  float originalX = movimentoX;
  movimentoX -= (movimentoY / tamanho) * tamanho * lateral;
  movimentoY += (originalX / tamanho) * tamanho * lateral;
}

// ==================== TREMOR FISIOLÓGICO ====================

void aplicarTremorFisiologico(int& moverX, int& moverY) {
  // Não cria deslocamento independente quando a fração planejada já foi
  // arredondada para zero. Isso evita pequenos passos fora do traçado no fim.
  if (moverX == 0 && moverY == 0) return;

  tremorFrequencia += (proximoAleatorio() * 0.004f);
  tremorFrequencia = limitarFloat(tremorFrequencia, 0.012f, 0.028f);
  tremorFase += tremorFrequencia;
  if (tremorFase > 6.2832f) tremorFase -= 6.2832f;

  float amplitudeTremor = TREMOR_AMPLITUDE_MIN +
    (TREMOR_AMPLITUDE_MAX - TREMOR_AMPLITUDE_MIN) *
    (1.0f - limitarFloat(mediaMagnitude / 30.0f, 0.0f, 1.0f));

  float tremorX = sin(tremorFase) * amplitudeTremor;
  float tremorY = cos(tremorFase * 1.07f) * amplitudeTremor;

  moverX += arredondarFloat(tremorX);
  moverY += arredondarFloat(tremorY);
}

// ==================== OVERSHOOT ====================

void verificarOvershoot(int dxComando) {
  // Movimento somente vertical não deve alterar a direção X. No firmware
  // antigo, dx=0 era tratado como direção negativa e podia gerar overshoot
  // falso no primeiro movimento positivo seguinte.
  if (dxComando == 0) return;

  bool xPositivo = (dxComando > 0);
  if (!primeiraDirecao && (xPositivo != direcaoXPositiva) && abs(dxComando) >= 2) {
    if (proximoAleatorioPositivo() < OVERSHOOT_PROB) {
      float extra = (float)dxComando * (OVERSHOOT_FATOR - 1.0f) * 0.5f;
      if (direcaoXPositiva) {
        overshootPorTickX = arredondarFloat(extra);
        overshootCorrigirX = -arredondarFloat(extra * 1.2f);
      } else {
        overshootPorTickX = -arredondarFloat(extra);
        overshootCorrigirX = arredondarFloat(extra * 1.2f);
      }
      overshootTickRestante = OVERSHOOT_TICKS;
      emOvershoot = true;
    }
  }

  direcaoXPositiva = xPositivo;
  primeiraDirecao = false;
}

void aplicarOvershoot(int& moverX, int& moverY) {
  if (!emOvershoot && overshootTickRestante == 0) return;

  if (overshootTickRestante > 0) {
    moverX += overshootPorTickX;
    moverY += overshootPorTickY;
    overshootTickRestante--;
  } else if (emOvershoot) {
    moverX += overshootCorrigirX;
    moverY += overshootCorrigirY;
    emOvershoot = false;
    overshootCorrigirX = 0;
    overshootCorrigirY = 0;
    overshootPorTickX = 0;
    overshootPorTickY = 0;
  }
}

// ==================== LÓGICA PRINCIPAL ====================

void pararMovimento() {
  pendenteX = 0.0f;
  pendenteY = 0.0f;
  reiniciarHumanizacao();

  emOvershoot = false;
  overshootTickRestante = 0;
  overshootPorTickX = 0;
  overshootPorTickY = 0;
  overshootCorrigirX = 0;
  overshootCorrigirY = 0;

  // Cada traçado começa sem herdar direção, tremor ou limite de velocidade
  // do traçado anterior. Isso deixa a curva mais previsível e elimina
  // overshoot fantasma na primeira mudança de direção de uma nova linha.
  mediaMagnitude = 8.0f;
  movimentoMaximoAtual = MOVIMENTO_MAXIMO_PADRAO;
  direcaoXPositiva = true;
  direcaoYPositiva = true;
  primeiraDirecao = true;
  tremorFase = 0.0f;
  tremorFrequencia = TREMOR_FREQ_BASE;
  proximoTick = millis();
}

void adicionarMovimento(int dx, int dy) {
  if (dx == 0 && dy == 0) {
    pararMovimento();
    return;
  }

  float mag = sqrt((float)(dx * dx + dy * dy));
  mediaMagnitude += (mag - mediaMagnitude) * MAGNITUDE_ALPHA;
  mediaMagnitude = limitarFloat(mediaMagnitude, 0.5f, 50.0f);

  int calcMax = (int)(mediaMagnitude * 0.5f + 2.0f);
  if (calcMax < MOVIMENTO_MAXIMO_BAIXO) calcMax = MOVIMENTO_MAXIMO_BAIXO;
  if (calcMax > MOVIMENTO_MAXIMO_ALTO) calcMax = MOVIMENTO_MAXIMO_ALTO;
  movimentoMaximoAtual = calcMax;

  verificarOvershoot(dx);
  pendenteX = limitarPendente(pendenteX + (float)dx);
  pendenteY = limitarPendente(pendenteY + (float)dy);
}

void atualizarMovimento() {
  unsigned long agora = millis();
  if ((long)(agora - proximoTick) < 0) return;

  float variacaoIntervalo = proximoAleatorioPositivo();
  unsigned long intervaloAtual = INTERVALO_MIN_MS +
    (unsigned long)(variacaoIntervalo * (INTERVALO_MAX_MS - INTERVALO_MIN_MS));
  if (mediaMagnitude > 12.0f && intervaloAtual > 2) intervaloAtual--;
  if (mediaMagnitude < 3.0f && intervaloAtual < INTERVALO_MAX_MS) intervaloAtual++;

  proximoTick = agora + intervaloAtual;

  if (pendenteX == 0.0f && pendenteY == 0.0f) return;

  float fracaoAtual = FRACAO_MIN +
    (proximoAleatorioPositivo() * (FRACAO_MAX - FRACAO_MIN));
  if (mediaMagnitude > 10.0f) {
    fracaoAtual = limitarFloat(fracaoAtual + 0.08f, FRACAO_MIN, FRACAO_MAX);
  }

  float tentativaX = pendenteX * fracaoAtual;
  float tentativaY = pendenteY * fracaoAtual;

  humanizarTrajetoriaPerpendicular(tentativaX, tentativaY);

  int moverX = arredondarFloat(tentativaX);
  int moverY = arredondarFloat(tentativaY);

  aplicarOvershoot(moverX, moverY);

  if ((moverX == 1 || moverX == -1 || moverX == 0) &&
      (moverY == 1 || moverY == -1 || moverY == 0)) {
    if (proximoAleatorioPositivo() < ZONA_MORTA_CHANCE) {
      if (abs(pendenteX) < 2.5f) moverX = 0;
      if (abs(pendenteY) < 2.5f) moverY = 0;
    }
  }

  if (moverX == 0 && pendenteX >= 0.8f) moverX = 1;
  if (moverX == 0 && pendenteX <= -0.8f) moverX = -1;
  if (moverY == 0 && pendenteY >= 0.8f) moverY = 1;
  if (moverY == 0 && pendenteY <= -0.8f) moverY = -1;

  aplicarTremorFisiologico(moverX, moverY);

  moverX = limitarMovimento(moverX);
  moverY = limitarMovimento(moverY);

  if (moverX != 0 || moverY != 0) {
    BootMouse.move(moverX, moverY);
    pendenteX -= (float)moverX;
    pendenteY -= (float)moverY;
  }
}

// ==================== CLICK COM BootMouse ====================

void clickEsquerdo() {
  BootMouse.press(MOUSE_LEFT);
  mouseEsquerdoPressionado = true;
  delay(30 + (int)(proximoAleatorioPositivo() * 15));
  BootMouse.release(MOUSE_LEFT);
  mouseEsquerdoPressionado = false;
}

void clickDireito() {
  BootMouse.press(MOUSE_RIGHT);
  mouseDireitoPressionado = true;
  delay(30 + (int)(proximoAleatorioPositivo() * 15));
  BootMouse.release(MOUSE_RIGHT);
  mouseDireitoPressionado = false;
}

void verificarLiberacaoDeSeguranca() {
  if (!mouseEsquerdoPressionado && !mouseDireitoPressionado) return;

  unsigned long agora = millis();
  if ((unsigned long)(agora - ultimoComandoSerial) < SILENCIO_MAXIMO_MOUSE_MS) {
    return;
  }

  if (mouseEsquerdoPressionado) {
    BootMouse.release(MOUSE_LEFT);
    mouseEsquerdoPressionado = false;
  }
  if (mouseDireitoPressionado) {
    BootMouse.release(MOUSE_RIGHT);
    mouseDireitoPressionado = false;
  }

  pararMovimento();
  Serial.println("SAFE RELEASE");
}

// ==================== COMANDOS SERIAIS ====================

void executar(char* comando) {
  int x, y, z;
  ultimoComandoSerial = millis();

  if (strncmp(comando, "MOVE ", 5) == 0) {
    const char* texto = comando + 5;
    if (lerInt(texto, x) && lerInt(texto, y) && fimDoComando(texto)) {
      adicionarMovimento(x, y);
    } else {
      Serial.println("ERR MOVE");
    }
    return;
  }

  if (strcmp(comando, "CLICK LEFT") == 0) {
    clickEsquerdo();
    return;
  }
  if (strcmp(comando, "CLICK RIGHT") == 0) {
    clickDireito();
    return;
  }

  if (strcmp(comando, "PRESS LEFT") == 0) {
    BootMouse.press(MOUSE_LEFT);
    mouseEsquerdoPressionado = true;
    return;
  }
  if (strcmp(comando, "RELEASE LEFT") == 0) {
    BootMouse.release(MOUSE_LEFT);
    mouseEsquerdoPressionado = false;
    pararMovimento();
    return;
  }
  if (strcmp(comando, "PRESS RIGHT") == 0) {
    BootMouse.press(MOUSE_RIGHT);
    mouseDireitoPressionado = true;
    return;
  }
  if (strcmp(comando, "RELEASE RIGHT") == 0) {
    BootMouse.release(MOUSE_RIGHT);
    mouseDireitoPressionado = false;
    pararMovimento();
    return;
  }

  if (strncmp(comando, "HUMANIZE ", 9) == 0) {
    const char* texto = comando + 9;
    if (lerInt(texto, x) && lerInt(texto, y) && lerInt(texto, z) &&
        fimDoComando(texto)) {
      humanizacaoForcaMaxima = limitarFloat((float)x / 1000.0f, 0.0f, 1.0f);
      humanizacaoSuavizacao = limitarFloat((float)y / 1000.0f, 0.01f, 0.50f);
      humanizacaoTicksPorAlvo = (byte)constrain(z, 1, 80);
      reiniciarHumanizacao();
      Serial.println("OK HUMANIZE");
    } else {
      Serial.println("ERR HUMANIZE");
    }
    return;
  }

  if (strcmp(comando, "PING") == 0) {
    Serial.println("PONG");
    return;
  }

  Serial.println("ERR UNKNOWN");
}

void lerSerial() {
  while (Serial.available() > 0) {
    char caractere = Serial.read();

    if (caractere == '\r') continue;

    if (caractere == '\n') {
      if (bufferOverflow) {
        Serial.println("ERR BUFFER");
      } else {
        buffer[idx] = '\0';
        if (idx > 0) executar(buffer);
      }
      idx = 0;
      bufferOverflow = false;
      continue;
    }

    if (bufferOverflow) continue;

    if (idx < sizeof(buffer) - 1) {
      buffer[idx++] = caractere;
    } else {
      // Descarta a linha inteira até o \n. O firmware antigo zerava o índice
      // e podia executar somente o final truncado de um comando inválido.
      bufferOverflow = true;
    }
  }
}

// ==================== SETUP E LOOP ====================

void setup() {
  Serial.begin(BAUD);

  // Inicializa o BootMouse (ao invés de Mouse.begin())
  BootMouse.begin();

  // Semeia PRNG
  estadoAleatorio ^= micros()
    ^ ((unsigned long)analogRead(A0) << 16)
    ^ 0xABCD1234UL;
  for (byte i = 0; i < 10; i++) proximoAleatorio();

  delay(1500);
  Serial.println("READY");
  ultimoComandoSerial = millis();
  pararMovimento();
}

void loop() {
  lerSerial();
  atualizarMovimento();
  verificarLiberacaoDeSeguranca();
}
