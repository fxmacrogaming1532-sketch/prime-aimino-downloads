param(
  [string]$AgentDir = (Split-Path -Parent $MyInvocation.MyCommand.Path),
  [switch]$Apply,
  [int]$ParentPid = 0
)

$ErrorActionPreference = "Stop"
# O instalador permite qualquer subpasta escolhida pelo usuário (por padrão,
# %LOCALAPPDATA%\PRIME AIMINO). Atualizações permanecem no mesmo diretório.
$officialAgentDir = [IO.Path]::GetFullPath($AgentDir).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
$repo = "fxmacrogaming1532-sketch/prime-aimino-downloads"
$apiUrl = "https://api.github.com/repos/$repo/releases/latest"
$installerUrl = "https://github.com/$repo/releases/latest/download/PRIME_AIMINO_INSTALADOR_WINDOWS.exe"
$versionPath = Join-Path $officialAgentDir "agent_version.json"
$logPath = Join-Path $officialAgentDir "agent-update.log"
$parentStopped = $false
$userSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$taskName = "PRIME AIMINO Agent - $userSid"

function Write-UpdateLog([string]$Message) {
  try {
    Add-Content -LiteralPath $logPath -Value "$(Get-Date -Format o) $Message"
  } catch { }
}

try {
  $localVersion = "0.0.0"
  if (Test-Path $versionPath) {
    $localVersion = [string](Get-Content -LiteralPath $versionPath -Raw | ConvertFrom-Json).version
  }
  $release = Invoke-RestMethod -Uri $apiUrl -Headers @{ "Accept" = "application/vnd.github+json"; "User-Agent" = "PRIME-AIMINO-Agent" } -TimeoutSec 20
  $latestVersion = ([string]$release.tag_name).TrimStart("v", "V")
  $local = [version]$localVersion
  $latest = [version]$latestVersion
  if ($latest -le $local) { exit 0 }
  if (-not $Apply) { exit 10 }

  $tempInstaller = Join-Path $env:TEMP ("PRIME_AIMINO_UPDATE_{0}.exe" -f ([guid]::NewGuid().ToString("N")))
  Invoke-WebRequest -Uri $installerUrl -OutFile $tempInstaller -UseBasicParsing -TimeoutSec 120
  if (-not (Test-Path $tempInstaller) -or (Get-Item $tempInstaller).Length -lt 1MB) {
    throw "O instalador baixado está incompleto."
  }

  if ($ParentPid -gt 0) {
    Stop-Process -Id $ParentPid -Force -ErrorAction SilentlyContinue
    $parentStopped = $true
    Start-Sleep -Seconds 2
  }

  $arguments = @("/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART", "/CLOSEAPPLICATIONS", "/DIR=$officialAgentDir")
  $process = Start-Process -FilePath $tempInstaller -ArgumentList $arguments -Wait -PassThru -WindowStyle Hidden
  if ($process.ExitCode -ne 0) { throw "O instalador retornou código $($process.ExitCode)." }
  Remove-Item -LiteralPath $tempInstaller -Force -ErrorAction SilentlyContinue

  $installerScript = Join-Path $officialAgentDir "instalar_agente_silencioso.ps1"
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File $installerScript -StartNow
  if ($LASTEXITCODE -ne 0) { throw "Não foi possível reativar a tarefa do agente." }
  Write-UpdateLog "updated from $localVersion to $latestVersion"
} catch {
  Write-UpdateLog ("update-failed: " + $_.Exception.Message)
  # Nunca deixe o agente desligado caso a troca do instalador falhe depois de
  # encerrarmos o processo antigo. A tarefa agendada é o watchdog oficial.
  if ($parentStopped) {
    try { Start-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue } catch { }
  }
  exit 1
}
