$ErrorActionPreference = "Stop"
$agentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$expectedAgentDir = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "PRIME AIMINO")).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
$actualAgentDir = [IO.Path]::GetFullPath($agentDir).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
if ($actualAgentDir -ne $expectedAgentDir) { throw "Instalação fora da pasta oficial do usuário atual: $expectedAgentDir" }
$runtimePath = Join-Path $expectedAgentDir "python_runtime.json"
$runtime = if (Test-Path -LiteralPath $runtimePath) { Get-Content -LiteralPath $runtimePath -Raw | ConvertFrom-Json } else { $null }
if (-not $runtime -or -not (Test-Path -LiteralPath ([string]$runtime.executable) -PathType Leaf)) { throw "Python do usuário não foi configurado. Execute preparar_este_pc.ps1 primeiro." }
$python = [string]$runtime.executable
$prefix = @($runtime.prefix)
$agentScript = Join-Path $expectedAgentDir "prime_aimino_agent.py"
if (-not (Test-Path -LiteralPath $agentScript -PathType Leaf)) { throw "prime_aimino_agent.py não encontrado na instalação oficial." }
$protocolKey = "HKCU:\Software\Classes\primeaimino"
New-Item -Path $protocolKey -Force | Out-Null
Set-ItemProperty -Path $protocolKey -Name "(default)" -Value "URL: PRIME AIMINO Activation" -Force
New-ItemProperty -Path $protocolKey -Name "URL Protocol" -Value "" -PropertyType String -Force | Out-Null
New-Item -Path "$protocolKey\shell\open\command" -Force | Out-Null
$arguments = (($prefix + @($agentScript, "activate-uri", '"%1"')) | ForEach-Object { '"' + $_ + '"' }) -join " "
Set-ItemProperty -Path "$protocolKey\shell\open\command" -Name "(default)" -Value "`"$python`" $arguments" -Force
Write-Output "Ativação automática Python registrada para o usuário atual."
