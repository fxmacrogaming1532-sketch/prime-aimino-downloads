import sys

from modulos.painel import painel_main
from modulos.rastreador_motor import tracker_main


def main():
    if "--tracker" in sys.argv:
        tracker_main()
    else:
        painel_main()


if __name__ == "__main__":
    main()

