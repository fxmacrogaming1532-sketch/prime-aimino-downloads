Option Explicit

Dim shell, fso, agentDir, setupScript
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
agentDir = fso.GetParentFolderName(WScript.ScriptFullName)
setupScript = agentDir & "\preparar_este_pc.ps1"
shell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -File " & Quote(setupScript), 0, False

Function Quote(value)
  Quote = Chr(34) & Replace(value, Chr(34), Chr(34) & Chr(34)) & Chr(34)
End Function
